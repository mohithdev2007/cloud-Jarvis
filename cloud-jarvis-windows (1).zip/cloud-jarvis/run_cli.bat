@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call "%~dp0install_and_run.bat"
    exit /b %errorlevel%
)
".venv\Scripts\python.exe" "%~dp0jarvis.py" --cli
