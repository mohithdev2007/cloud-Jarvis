@echo off
setlocal
cd /d "%~dp0"
title Cloud J.A.R.V.I.S. — Potato-PC Windows Installer ^& Launcher

echo ============================================================
echo   CLOUD J.A.R.V.I.S. (Potato-PC Windows Edition)
echo   0%% Local GPU  ^|  ~28 MB RAM  ^|  OpenAI Cloud Brain + Voice
echo ============================================================
echo.

:: Detect Python (supports both python.exe and Windows py.exe launcher)
set "PY_CMD="
where python >nul 2>nul
if %errorlevel%==0 (
    python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
    if not errorlevel 1 set "PY_CMD=python"
)

if "%PY_CMD%"=="" (
    where py >nul 2>nul
    if %errorlevel%==0 (
        py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
        if not errorlevel 1 set "PY_CMD=py -3"
    )
)

if "%PY_CMD%"=="" (
    echo [ERROR] Python 3.9+ was not found on this PC.
    echo Please install Python from https://www.python.org/downloads/
    echo ^(Check "Add python.exe to PATH" during installation^).
    echo.
    pause
    exit /b 1
)

:: Create lightweight virtual environment on first run
if not exist ".venv\Scripts\python.exe" (
    echo [1/2] Creating lightweight Python virtual environment...
    %PY_CMD% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create .venv folder.
        pause
        exit /b 1
    )
)

:: Install tiny prebuilt wheels only once (fast startup on every launch after!)
if not exist ".venv\.installed_ok" (
    echo [2/2] Installing lightweight Cloud JARVIS packages ^(no heavy AI bloat^)...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Package installation failed. Check your internet connection.
        pause
        exit /b 1
    )
    echo ok > ".venv\.installed_ok"
    echo [OK] Setup complete!
)

if not exist ".env" (
    if exist ".env.example" copy /Y ".env.example" ".env" >nul
)

echo Launching J.A.R.V.I.S. ...
".venv\Scripts\python.exe" -c "import tkinter" >nul 2>nul
if %errorlevel%==0 (
    start "" ".venv\Scripts\pythonw.exe" "%~dp0jarvis.py"
) else (
    ".venv\Scripts\python.exe" "%~dp0jarvis.py" --cli
)
exit /b 0
