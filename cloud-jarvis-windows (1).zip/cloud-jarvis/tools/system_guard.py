"""Potato-PC Resource Monitor, Multi-Process Hog Detector, & Win32 RAM Booster."""

from __future__ import annotations

import ctypes
import gc
import os
import sys
from collections import defaultdict
from typing import Dict, List, Tuple

import psutil

# Strict allow-never-kill blocklist of critical Windows & session processes
PROTECTED_PROCESS_NAMES = {
    "system",
    "system idle process",
    "registry",
    "smss.exe",
    "csrss.exe",
    "wininit.exe",
    "services.exe",
    "lsass.exe",
    "svchost.exe",
    "winlogon.exe",
    "explorer.exe",
    "dwm.exe",
    "fontdrvhost.exe",
    "sihost.exe",
    "taskhostw.exe",
    "ctfmon.exe",
    "audiodg.exe",
    "spoolsv.exe",
    "searchindexer.exe",
    "searchhost.exe",
    "startmenuexperiencehost.exe",
    "shellexperiencehost.exe",
    "runtimebroker.exe",
    "securityhealthservice.exe",
    "msmpeng.exe",
    "conhost.exe",
}


def get_live_hud_metrics() -> Tuple[float, float, float]:
    """Fast non-blocking metrics for HUD bar: (cpu_percent, ram_percent, jarvis_ram_mb)."""
    cpu = psutil.cpu_percent(interval=None)
    vm = psutil.virtual_memory()
    own_mb = psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
    return cpu, vm.percent, own_mb


def _aggregate_processes_by_name() -> List[Tuple[str, float, int]]:
    """Aggregate RSS memory across multi-process apps (e.g. Chrome/Discord sub-processes)."""
    mem_by_name: Dict[str, int] = defaultdict(int)
    count_by_name: Dict[str, int] = defaultdict(int)

    for proc in psutil.process_iter(["name", "memory_info"]):
        try:
            info = proc.info
            name = (info.get("name") or "Unknown").strip()
            mem_info = info.get("memory_info")
            if mem_info:
                mem_by_name[name] += mem_info.rss
                count_by_name[name] += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    ranked = [
        (name, rss_bytes / (1024 * 1024), count_by_name[name])
        for name, rss_bytes in mem_by_name.items()
    ]
    ranked.sort(key=lambda item: item[1], reverse=True)
    return ranked


def get_pc_health_report() -> str:
    """Comprehensive system health & RAM hog report tailored for low-spec PCs."""
    cpu_pct = psutil.cpu_percent(interval=0.25)
    cores_phys = psutil.cpu_count(logical=False) or 1
    cores_log = psutil.cpu_count(logical=True) or 1
    vm = psutil.virtual_memory()

    disk_root = "C:\\" if sys.platform == "win32" else "/"
    disk = psutil.disk_usage(disk_root)
    own_mb = psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)

    lines = [
        f"CPU Usage: {cpu_pct:.1f}% ({cores_phys} cores / {cores_log} threads)",
        f"RAM Usage: {vm.percent:.1f}% ({vm.used / (1024**3):.2f} GB used of {vm.total / (1024**3):.2f} GB; {vm.available / (1024**3):.2f} GB available)",
        f"Disk ({disk_root}): {disk.percent:.1f}% used ({disk.free / (1024**3):.1f} GB free of {disk.total / (1024**3):.1f} GB)",
        f"Cloud JARVIS Footprint: {own_mb:.1f} MB RAM (0% GPU)",
    ]

    batt = getattr(psutil, "sensors_battery", lambda: None)()
    if batt is not None:
        plug = "Plugged in" if batt.power_plugged else "On battery"
        lines.append(f"Battery: {batt.percent:.0f}% ({plug})")

    top_hogs = _aggregate_processes_by_name()[:7]
    if top_hogs:
        lines.append("\nTop Memory-Consuming Applications:")
        for name, mb, cnt in top_hogs:
            proc_note = f" ({cnt} processes)" if cnt > 1 else ""
            lines.append(f"  - {name}{proc_note}: {mb:.0f} MB")

    return "\n".join(lines)


def boost_potato_ram() -> str:
    """Safely trim idle working-set RAM across Windows background processes without closing apps."""
    gc.collect()
    vm_before = psutil.virtual_memory()
    avail_before_mb = vm_before.available / (1024 * 1024)

    if sys.platform != "win32":
        return (
            f"Garbage collection complete. Current RAM usage: {vm_before.percent:.1f}% "
            f"({avail_before_mb:.0f} MB available). Note: Win32 EmptyWorkingSet boost activates on Windows."
        )

    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_SET_QUOTA = 0x0100
    kernel32 = ctypes.windll.kernel32
    psapi = ctypes.windll.psapi

    kernel32.OpenProcess.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.c_uint]
    kernel32.OpenProcess.restype = ctypes.c_void_p
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = ctypes.c_int

    empty_fn = getattr(psapi, "EmptyWorkingSet", None) or getattr(
        kernel32, "K32EmptyWorkingSet", None
    )
    if empty_fn is None:
        return "EmptyWorkingSet API unavailable on this Windows build."
    empty_fn.argtypes = [ctypes.c_void_p]
    empty_fn.restype = ctypes.c_int

    own_pid = os.getpid()
    trimmed_count = 0

    for proc in psutil.process_iter(["pid", "name"]):
        try:
            pid = proc.info["pid"]
            if not pid or pid == own_pid or pid <= 4:
                continue
            handle = kernel32.OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, 0, pid
            )
            if handle:
                try:
                    if empty_fn(handle):
                        trimmed_count += 1
                finally:
                    kernel32.CloseHandle(handle)
        except Exception:
            continue

    vm_after = psutil.virtual_memory()
    avail_after_mb = vm_after.available / (1024 * 1024)
    freed_mb = max(0.0, avail_after_mb - avail_before_mb)

    return (
        f"Potato RAM Boost complete: trimmed idle working sets on {trimmed_count} processes. "
        f"Reclaimed ~{freed_mb:.0f} MB of active RAM "
        f"(RAM usage: {vm_before.percent:.1f}% -> {vm_after.percent:.1f}%, "
        f"{vm_after.available / (1024**3):.2f} GB now free)."
    )


def close_application_processes(app_name: str) -> str:
    """Safely close a user-specified background hog while protecting Windows system processes."""
    target = (app_name or "").strip().lower()
    if not target:
        return "Please specify an application name to close."

    if target in PROTECTED_PROCESS_NAMES or target in {"python", "python.exe", "pythonw.exe"}:
        return f"Safety block: '{app_name}' is a protected system or JARVIS runtime process."

    own_pid = os.getpid()
    matched: List[psutil.Process] = []
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            pname = (proc.info.get("name") or "").strip()
            pname_low = pname.lower()
            if not pname_low or pname_low in PROTECTED_PROCESS_NAMES or proc.info["pid"] == own_pid:
                continue
            stem = pname_low[:-4] if pname_low.endswith(".exe") else pname_low
            if target == pname_low or target == stem or (len(target) >= 4 and target in stem):
                matched.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if not matched:
        return f"No running non-system processes matched '{app_name}'."

    freed_bytes = 0
    closed_names = set()
    for p in matched:
        try:
            freed_bytes += p.memory_info().rss
            closed_names.add(p.name())
            p.terminate()
        except Exception:
            continue

    psutil.wait_procs(matched, timeout=2.0)
    return (
        f"Closed {len(matched)} process(es) ({', '.join(sorted(closed_names))}), "
        f"releasing ~{freed_bytes / (1024 * 1024):.0f} MB of RAM."
    )
