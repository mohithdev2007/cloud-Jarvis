"""Windows PC Control Tools — Zero-bloat Win32 / stdlib implementation."""

from __future__ import annotations

import ctypes
import difflib
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path
from typing import Dict, List, Optional

# Built-in Windows executables & modern URI schemes
BUILTIN_APP_ALIASES: Dict[str, str] = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "calc": "calc.exe",
    "paint": "mspaint.exe",
    "file explorer": "explorer.exe",
    "explorer": "explorer.exe",
    "task manager": "taskmgr.exe",
    "taskmgr": "taskmgr.exe",
    "command prompt": "cmd.exe",
    "cmd": "cmd.exe",
    "powershell": "powershell.exe",
    "control panel": "control.exe",
    "snipping tool": "snippingtool.exe",
    "settings": "ms-settings:",
    "windows settings": "ms-settings:",
    "wifi settings": "ms-settings:network-wifi",
    "bluetooth": "ms-settings:bluetooth",
    "bluetooth settings": "ms-settings:bluetooth",
    "display settings": "ms-settings:display",
    "sound settings": "ms-settings:sound",
    "windows update": "ms-settings:windowsupdate",
    "camera": "microsoft.windows.camera:",
    "spotify": "spotify:",
    "discord": "discord:",
    "steam": "steam:",
    "whatsapp": "whatsapp:",
    "vs code": "code",
    "vscode": "code",
    "visual studio code": "code",
    "microsoft edge": "msedge",
    "edge": "msedge",
    "chrome": "chrome",
    "google chrome": "chrome",
    "firefox": "firefox",
    "brave": "brave",
}

# Win32 Virtual-Key Codes for Media & Volume
VK_VOLUME_MUTE = 0xAD
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_UP = 0xAF
VK_MEDIA_NEXT_TRACK = 0xB0
VK_MEDIA_PREV_TRACK = 0xB1
VK_MEDIA_STOP = 0xB2
VK_MEDIA_PLAY_PAUSE = 0xB3
VK_LWIN = 0x5B
VK_D = 0x44
KEYEVENTF_KEYUP = 0x0002

_START_MENU_CACHE: Optional[Dict[str, str]] = None


def scan_start_menu_apps(force_refresh: bool = False) -> Dict[str, str]:
    """Scan Windows Start Menu shortcut folders (<15ms) and cache app_name -> path."""
    global _START_MENU_CACHE
    if _START_MENU_CACHE is not None and not force_refresh:
        return _START_MENU_CACHE

    apps: Dict[str, str] = {}
    if sys.platform == "win32":
        roots = [
            os.environ.get("APPDATA", ""),
            os.environ.get("PROGRAMDATA", ""),
        ]
        for root in roots:
            if not root:
                continue
            sm_dir = Path(root) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
            if not sm_dir.exists():
                continue
            try:
                for item in sm_dir.rglob("*"):
                    if item.suffix.lower() in {".lnk", ".url"} and item.is_file():
                        stem = item.stem.strip().lower()
                        if stem and not stem.startswith("uninstall"):
                            apps.setdefault(stem, str(item))
            except Exception:
                continue

    _START_MENU_CACHE = apps
    return apps


def _start_target_windows(target: str) -> None:
    """Launch an executable, .lnk shortcut, or URI scheme cleanly on Windows."""
    if sys.platform == "win32":
        os.startfile(target)  # type: ignore[attr-defined]
    else:
        if target.startswith(("http://", "https://")):
            webbrowser.open(target)
        else:
            subprocess.Popen(
                [target],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )


def open_application(app_name: str) -> str:
    """Launch an installed desktop app, Windows tool, or URI scheme by name."""
    query = (app_name or "").strip().lower()
    if not query:
        return "Please provide an application name to open."

    # 1. Check Start Menu indexed shortcuts first (exact then fuzzy) for real desktop installs
    sm_apps = scan_start_menu_apps()
    if query in sm_apps:
        try:
            _start_target_windows(sm_apps[query])
            return f"Opened '{app_name}' via Start Menu shortcut."
        except Exception:
            pass

    # 2. Check built-in aliases & URI schemes
    if query in BUILTIN_APP_ALIASES:
        alias_target = BUILTIN_APP_ALIASES[query]
        # Verify executable on PATH if not a URI or .exe in System32
        if ":" in alias_target or alias_target.endswith(".exe") or shutil.which(alias_target):
            try:
                _start_target_windows(alias_target)
                return f"Launched '{app_name}'."
            except Exception:
                pass

    # 3. Substring / fuzzy match against Start Menu shortcuts
    substring_hits = [name for name in sm_apps if query in name]
    if substring_hits:
        best = min(substring_hits, key=len)
        try:
            _start_target_windows(sm_apps[best])
            return f"Opened '{best.title()}'."
        except Exception as exc:
            return f"Found '{best}' but could not launch it: {exc}"

    fuzzy_hits = difflib.get_close_matches(query, list(sm_apps.keys()), n=1, cutoff=0.65)
    if fuzzy_hits:
        best = fuzzy_hits[0]
        try:
            _start_target_windows(sm_apps[best])
            return f"Opened closest installed match: '{best.title()}'."
        except Exception as exc:
            return f"Found '{best}' but failed to launch: {exc}"

    # 4. Direct executable on PATH
    which_hit = shutil.which(query)
    if which_hit:
        try:
            subprocess.Popen(
                [which_hit],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return f"Started '{query}' from system PATH."
        except Exception as exc:
            return f"Failed to start '{query}': {exc}"

    return (
        f"Could not find an installed application matching '{app_name}'. "
        "Tip: Call list_installed_apps to see available Start Menu programs, or open its website instead."
    )


def list_installed_apps(filter_query: str = "") -> str:
    """List Start Menu applications discovered on this PC."""
    sm_apps = scan_start_menu_apps(force_refresh=True)
    q = (filter_query or "").strip().lower()
    names = sorted(sm_apps.keys())
    if q:
        names = [n for n in names if q in n]
    if not names:
        if sys.platform != "win32":
            return "Start Menu scanning is active when running on Windows."
        return f"No Start Menu shortcuts matched '{filter_query}'."
    preview = [n.title() for n in names[:50]]
    suffix = f"\n...and {len(names) - 50} more." if len(names) > 50 else ""
    return "Installed Start Menu apps:\n- " + "\n- ".join(preview) + suffix


_BROWSER_SPECS: Dict[str, tuple[str, list[str]]] = {
    "brave": (
        "brave.exe",
        [
            r"%PROGRAMFILES%\BraveSoftware\Brave-Browser\Application\brave.exe",
            r"%PROGRAMFILES(X86)%\BraveSoftware\Brave-Browser\Application\brave.exe",
            r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe",
        ],
    ),
    "chrome": (
        "chrome.exe",
        [
            r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe",
            r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe",
            r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
        ],
    ),
    "edge": (
        "msedge.exe",
        [
            r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe",
            r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe",
        ],
    ),
    "firefox": (
        "firefox.exe",
        [
            r"%PROGRAMFILES%\Mozilla Firefox\firefox.exe",
            r"%PROGRAMFILES(X86)%\Mozilla Firefox\firefox.exe",
        ],
    ),
    "opera": (
        "opera.exe",
        [
            r"%LOCALAPPDATA%\Programs\Opera\opera.exe",
            r"%LOCALAPPDATA%\Programs\Opera GX\opera.exe",
        ],
    ),
}


def _find_browser_executable(browser_name: str) -> Optional[str]:
    """Locate specific browser .exe via Windows Registry App Paths, standard paths, or PATH."""
    b = (browser_name or "default").strip().lower()
    if b in {"", "default", "auto"}:
        return None
    for key in _BROWSER_SPECS:
        if key in b:
            b = key
            break
    if b not in _BROWSER_SPECS:
        return shutil.which(b)

    exe_name, candidate_paths = _BROWSER_SPECS[b]

    # 1. Check Windows Registry App Paths (works even on custom D:\ installs!)
    if sys.platform == "win32":
        try:
            import winreg

            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                try:
                    with winreg.OpenKey(
                        hive,
                        rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe_name}",
                    ) as reg_key:
                        val, _ = winreg.QueryValueEx(reg_key, "")
                        if val and Path(val).exists():
                            return val
                except OSError:
                    continue
        except Exception:
            pass

        # 2. Check standard Windows installation directories
        for raw_p in candidate_paths:
            expanded = os.path.expandvars(raw_p)
            if Path(expanded).exists():
                return expanded

    # 3. Check system PATH (Linux/Windows)
    for cmd_candidate in (exe_name, b, f"{b}-browser"):
        hit = shutil.which(cmd_candidate)
        if hit:
            return hit
    return None


def _open_url_with_browser(url: str, browser: str = "default") -> Tuple_str_bool:
    """Open URL in requested browser (e.g. 'brave') or fallback cleanly to default browser."""
    wanted = (browser or "default").strip().lower()
    if wanted not in {"", "default", "auto"}:
        exe_path = _find_browser_executable(wanted)
        if exe_path:
            subprocess.Popen(
                [exe_path, url],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return f"Opened in {wanted.title()}: {url}", True
        webbrowser.open(url)
        return (
            f"Could not find {wanted.title()} installed, so opened in default browser: {url}",
            False,
        )

    webbrowser.open(url)
    return f"Opened in default browser: {url}", True


Tuple_str_bool = tuple[str, bool]


def play_youtube_video(query: str, browser: str = "default") -> str:
    """Find the top matching YouTube video/song and auto-play it directly in the chosen browser."""
    q = (query or "").strip()
    if not q:
        return "Please provide a song or video name to play on YouTube."

    encoded = urllib.parse.quote_plus(q)
    search_url = f"https://www.youtube.com/results?search_query={encoded}"
    watch_url = search_url

    try:
        req = urllib.request.Request(
            search_url,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                )
            },
        )
        with urllib.request.urlopen(req, timeout=6.0) as resp:
            raw_html = resp.read().decode("utf-8", errors="ignore")
        video_ids = re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', raw_html)
        if video_ids:
            watch_url = f"https://www.youtube.com/watch?v={video_ids[0]}"
    except Exception:
        pass

    msg, _exact_browser = _open_url_with_browser(watch_url, browser)
    return f"Playing '{q}' on YouTube — {msg}"


def open_website(
    url_or_query: str, platform: str = "auto", browser: str = "default"
) -> str:
    """Open a website URL or search query in a specific browser (e.g. Brave, Chrome) or default browser."""
    raw = (url_or_query or "").strip()
    if not raw:
        return "No URL or search query provided."

    plat = (platform or "auto").strip().lower()
    encoded = urllib.parse.quote_plus(raw)

    if plat == "youtube":
        target = f"https://www.youtube.com/results?search_query={encoded}"
    elif plat == "google":
        target = f"https://www.google.com/search?q={encoded}"
    elif plat == "github":
        target = f"https://github.com/search?q={encoded}"
    elif plat == "reddit":
        target = f"https://www.reddit.com/search/?q={encoded}"
    elif plat == "wikipedia":
        target = f"https://en.wikipedia.org/wiki/Special:Search?search={encoded}"
    else:
        if raw.startswith(("http://", "https://")):
            target = raw
        elif "." in raw and " " not in raw:
            target = f"https://{raw}"
        else:
            target = f"https://www.google.com/search?q={encoded}"

    msg, _ = _open_url_with_browser(target, browser)
    return msg


def _tap_vk(vk_code: int, times: int = 1) -> None:
    if sys.platform != "win32":
        return
    user32 = ctypes.windll.user32
    for _ in range(max(1, times)):
        user32.keybd_event(vk_code, 0, 0, 0)
        user32.keybd_event(vk_code, 0, KEYEVENTF_KEYUP, 0)
        if times > 1:
            time.sleep(0.012)


def control_media_and_volume(action: str, value: int = 10) -> str:
    """Control Windows system audio volume and media playback."""
    act = (action or "").strip().lower()
    if sys.platform != "win32":
        return f"[Non-Windows preview] Simulated media/volume action: {act} ({value})."

    # Each Windows volume key tap adjusts master volume by 2%
    if act == "volume_up":
        taps = max(1, min(50, round(abs(value) / 2)))
        _tap_vk(VK_VOLUME_UP, taps)
        return f"Increased volume by ~{taps * 2}%."
    if act == "volume_down":
        taps = max(1, min(50, round(abs(value) / 2)))
        _tap_vk(VK_VOLUME_DOWN, taps)
        return f"Decreased volume by ~{taps * 2}%."
    if act == "set_volume":
        lvl = max(0, min(100, int(value)))
        # Reset to 0 cleanly (50 steps down) then step up to exact target %
        _tap_vk(VK_VOLUME_DOWN, 50)
        if lvl > 0:
            _tap_vk(VK_VOLUME_UP, max(1, round(lvl / 2)))
        return f"Set system volume to ~{lvl}%."
    if act in {"mute", "unmute", "mute_toggle"}:
        _tap_vk(VK_VOLUME_MUTE, 1)
        return "Toggled system mute."
    if act in {"play_pause", "play", "pause"}:
        _tap_vk(VK_MEDIA_PLAY_PAUSE, 1)
        return "Toggled media play/pause."
    if act == "next_track":
        _tap_vk(VK_MEDIA_NEXT_TRACK, 1)
        return "Skipped to next media track."
    if act == "prev_track":
        _tap_vk(VK_MEDIA_PREV_TRACK, 1)
        return "Returned to previous media track."
    if act == "stop_media":
        _tap_vk(VK_MEDIA_STOP, 1)
        return "Stopped media playback."

    return f"Unknown media/volume action '{action}'."


def set_screen_brightness(percent: int) -> str:
    """Adjust laptop/integrated display brightness on Windows via WMI."""
    lvl = max(5, min(100, int(percent)))
    if sys.platform != "win32":
        return f"[Non-Windows preview] Brightness set to {lvl}%."
    ps_cmd = (
        f"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods)"
        f".WmiSetBrightness(1,{lvl})"
    )
    try:
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        res = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=creation_flags,
        )
        if res.returncode == 0:
            return f"Set screen brightness to {lvl}%."
        return (
            "Could not adjust brightness via WMI (external desktop monitors usually "
            "require hardware OSD buttons or DDC/CI)."
        )
    except Exception as exc:
        return f"Brightness adjustment error: {exc}"


def clipboard_tool(action: str, text: str = "") -> str:
    """Read or write Windows clipboard using 64-bit-safe Win32 APIs."""
    act = (action or "read").strip().lower()
    if sys.platform != "win32":
        return (
            f"[Non-Windows clipboard] Would {act}: {text[:80]}"
            if act == "write"
            else "[Non-Windows preview: clipboard empty]"
        )

    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    user32.OpenClipboard.argtypes = [ctypes.c_void_p]
    user32.OpenClipboard.restype = ctypes.c_int
    user32.CloseClipboard.argtypes = []
    user32.CloseClipboard.restype = ctypes.c_int
    user32.EmptyClipboard.argtypes = []
    user32.EmptyClipboard.restype = ctypes.c_int
    user32.GetClipboardData.argtypes = [ctypes.c_uint]
    user32.GetClipboardData.restype = ctypes.c_void_p
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    user32.SetClipboardData.restype = ctypes.c_void_p

    kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.restype = ctypes.c_int

    if not user32.OpenClipboard(None):
        return "Clipboard is temporarily busy; please try again."

    try:
        if act == "read":
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return "Clipboard is empty or does not contain text."
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return "Could not lock clipboard buffer."
            try:
                content = ctypes.wstring_at(ptr)
            finally:
                kernel32.GlobalUnlock(handle)
            if len(content) > 4000:
                return content[:4000] + "\n...[truncated]"
            return content or "(Clipboard is empty)"

        elif act == "write":
            user32.EmptyClipboard()
            encoded = (text or "").encode("utf-16-le") + b"\x00\x00"
            h_mem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(encoded))
            if not h_mem:
                return "Failed to allocate clipboard memory."
            ptr = kernel32.GlobalLock(h_mem)
            if not ptr:
                return "Failed to lock allocated clipboard memory."
            ctypes.memmove(ptr, encoded, len(encoded))
            kernel32.GlobalUnlock(h_mem)
            user32.SetClipboardData(CF_UNICODETEXT, h_mem)
            return f"Copied {len(text)} characters to clipboard."
        else:
            return f"Unknown clipboard action '{action}'. Use 'read' or 'write'."
    finally:
        user32.CloseClipboard()


def system_desktop_action(action: str) -> str:
    """Perform safe Windows desktop actions (minimize_all, lock_pc, empty_recycle_bin, task_manager)."""
    act = (action or "").strip().lower()
    if sys.platform != "win32":
        return f"[Non-Windows preview] Executed desktop action: {act}"

    user32 = ctypes.windll.user32
    if act == "minimize_all":
        user32.keybd_event(VK_LWIN, 0, 0, 0)
        user32.keybd_event(VK_D, 0, 0, 0)
        user32.keybd_event(VK_D, 0, KEYEVENTF_KEYUP, 0)
        user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)
        return "Toggled Show Desktop (Win+D)."
    if act == "lock_pc":
        user32.LockWorkStation()
        return "Workstation locked."
    if act == "empty_recycle_bin":
        # SHERB_NOCONFIRMATION (1) | SHERB_NOPROGRESSUI (2) | SHERB_NOSOUND (4) = 7
        ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 7)
        return "Emptied the Windows Recycle Bin."
    if act == "task_manager":
        _start_target_windows("taskmgr.exe")
        return "Opened Windows Task Manager."

    return f"Unsupported action '{action}'."


def search_user_files(query: str, folder: str = "all") -> str:
    """Fast bounded search across Desktop, Downloads, Documents, Pictures."""
    q = (query or "").strip().lower()
    if not q:
        return "Please specify a filename or keyword to search for."

    home = Path.home()
    folder_map = {
        "desktop": [home / "Desktop"],
        "downloads": [home / "Downloads"],
        "documents": [home / "Documents"],
        "pictures": [home / "Pictures"],
        "all": [
            home / "Desktop",
            home / "Downloads",
            home / "Documents",
            home / "Pictures",
        ],
    }
    roots = folder_map.get(folder.strip().lower(), folder_map["all"])
    skip_dirs = {"node_modules", ".git", "__pycache__", ".venv", "venv", "AppData"}

    matches: List[str] = []
    scanned = 0
    for root in roots:
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [
                d for d in dirnames if d not in skip_dirs and not d.startswith(".")
            ]
            # Check matching folders too
            for d in dirnames:
                if q in d.lower():
                    matches.append(f"[DIR]  {Path(dirpath) / d}")
            for fn in filenames:
                scanned += 1
                if q in fn.lower():
                    matches.append(f"[FILE] {Path(dirpath) / fn}")
                if len(matches) >= 25 or scanned >= 15000:
                    break
            if len(matches) >= 25 or scanned >= 15000:
                break

    if not matches:
        return f"No files or folders matching '{query}' found in {folder}."
    return f"Found {len(matches)} match(es):\n" + "\n".join(matches)


def open_file_or_folder(path_str: str) -> str:
    """Open a specific file or folder in its default Windows application / Explorer."""
    p = Path(os.path.expanduser(path_str.strip())).resolve()
    if not p.exists():
        return f"Path does not exist: {p}"
    try:
        _start_target_windows(str(p))
        return f"Opened: {p}"
    except Exception as exc:
        return f"Could not open '{p}': {exc}"
