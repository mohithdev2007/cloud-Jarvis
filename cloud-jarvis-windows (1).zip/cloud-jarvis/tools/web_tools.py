"""Zero-dependency Live Web Search & Weather Lookup (IPv4-resilient stdlib urllib)."""

from __future__ import annotations

import html
import http.client
import json
import re
import socket
import ssl
import urllib.parse
import urllib.request
from typing import List

_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

_WMO_CODES = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    71: "Light snow",
    73: "Moderate snow",
    75: "Heavy snow",
    80: "Rain showers",
    81: "Moderate showers",
    82: "Heavy showers",
    95: "Thunderstorm",
}


class _IPv4PreferredHTTPSConnection(http.client.HTTPSConnection):
    """Prefer IPv4 first to avoid broken dual-stack IPv6 SSL timeouts on home Wi-Fi."""

    def connect(self) -> None:
        sock = None
        last_err = None
        for family in (socket.AF_INET, socket.AF_UNSPEC):
            try:
                infos = socket.getaddrinfo(
                    self.host, self.port, family, socket.SOCK_STREAM
                )
                for af, socktype, proto, _canon, sa in infos:
                    try:
                        s = socket.socket(af, socktype, proto)
                        s.settimeout(self.timeout)
                        s.connect(sa)
                        sock = s
                        break
                    except OSError as err:
                        last_err = err
                        continue
                if sock is not None:
                    break
            except OSError as err:
                last_err = err
                continue

        if sock is None:
            raise OSError(f"Connection failed to {self.host}: {last_err}")

        ctx = self._context if hasattr(self, "_context") else ssl.create_default_context()
        self.sock = ctx.wrap_socket(sock, server_hostname=self.host)


class _IPv4HTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req: urllib.request.Request):  # type: ignore[override]
        return self.do_open(_IPv4PreferredHTTPSConnection, req)


_OPENER = urllib.request.build_opener(_IPv4HTTPSHandler())


def _http_get(url: str, timeout: float = 7.0) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    with _OPENER.open(req, timeout=timeout) as resp:
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.read().decode(charset, errors="replace")


def search_the_web(query: str, max_results: int = 5) -> str:
    """Perform a live web search via DuckDuckGo HTML endpoint with zero extra API keys."""
    q = (query or "").strip()
    if not q:
        return "Please provide a search query."

    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote_plus(q)}"
    try:
        raw_html = _http_get(url, timeout=7.5)
    except Exception as exc:
        return f"Web search request failed: {exc}"

    title_pattern = re.compile(
        r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
        re.IGNORECASE | re.DOTALL,
    )
    snippet_pattern = re.compile(
        r'<a[^>]*class="result__snippet"[^>]*>(.*?)</a>|<div[^>]*class="result__snippet"[^>]*>(.*?)</div>',
        re.IGNORECASE | re.DOTALL,
    )

    titles = title_pattern.findall(raw_html)
    snippets = snippet_pattern.findall(raw_html)

    results: List[str] = []
    for idx, (href, raw_title) in enumerate(titles[: max(1, min(8, max_results))]):
        clean_title = html.unescape(re.sub(r"<[^>]+>", "", raw_title)).strip()
        parsed_href = href
        if "uddg=" in href:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
            if "uddg" in qs and qs["uddg"]:
                parsed_href = qs["uddg"][0]

        raw_snip = ""
        if idx < len(snippets):
            raw_snip = snippets[idx][0] or snippets[idx][1]
        clean_snip = html.unescape(re.sub(r"<[^>]+>", "", raw_snip)).strip()

        results.append(
            f"{idx + 1}. {clean_title}\n   URL: {parsed_href}\n   Snippet: {clean_snip}"
        )

    if not results:
        return f"No live web results returned for '{q}'."
    return "\n\n".join(results)


def get_live_weather(city: str) -> str:
    """Fetch real-time weather for any city using Open-Meteo (free, fast, no API key)."""
    loc = (city or "").strip()
    if not loc:
        return "Please provide a city name."

    try:
        geo_url = (
            "https://geocoding-api.open-meteo.com/v1/search?"
            f"name={urllib.parse.quote_plus(loc)}&count=1&language=en&format=json"
        )
        geo_data = json.loads(_http_get(geo_url, timeout=6.0))
        items = geo_data.get("results") or []
        if not items:
            return f"Could not find coordinates for '{loc}'."

        place = items[0]
        lat = place["latitude"]
        lon = place["longitude"]
        resolved_name = (
            f"{place.get('name')}, {place.get('admin1', '')}, {place.get('country', '')}"
            .replace(", ,", ",")
            .strip(", ")
        )

        wx_metno_url = (
            f"https://api.met.no/weatherapi/locationforecast/2.0/compact?lat={lat:.4f}&lon={lon:.4f}"
        )
        req = urllib.request.Request(
            wx_metno_url,
            headers={"User-Agent": "CloudJarvisPotatoEdition/1.0 (https://github.com)"},
        )
        with _OPENER.open(req, timeout=6.0) as resp:
            met_data = json.loads(resp.read().decode("utf-8", errors="replace"))

        ts0 = met_data["properties"]["timeseries"][0]["data"]
        details = ts0["instant"]["details"]
        temp = details.get("air_temperature")
        hum = details.get("relative_humidity")
        wind_ms = details.get("wind_speed", 0.0)
        wind_kmh = round(float(wind_ms) * 3.6, 1)
        summary_code = (
            ts0.get("next_1_hours", {}).get("summary", {}).get("symbol_code")
            or ts0.get("next_6_hours", {}).get("summary", {}).get("symbol_code")
            or "clear"
        )
        cond = summary_code.replace("_", " ").title()

        return (
            f"Weather in {resolved_name}: {cond}, {temp}°C, "
            f"Humidity: {hum}%, Wind: {wind_kmh} km/h."
        )
    except Exception as exc:
        return f"Weather lookup failed: {exc}"
