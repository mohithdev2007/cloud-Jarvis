"""Cross-Provider Function-Calling Tool Registry (Gemini Free + Groq Free + OpenRouter + OpenAI)."""

from __future__ import annotations

import json
from typing import Any, Callable, Dict, List, Optional

from core.config import JarvisConfig
from core.memory import JarvisMemory
from tools import system_guard, vision, web_tools, windows_control

OPENAI_TOOLS_SCHEMA: List[Dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "open_application",
            "description": (
                "Open or launch an application, program, game, or Windows utility on the user's PC "
                "(e.g., 'Chrome', 'Spotify', 'VS Code', 'Discord', 'Calculator', 'Settings', 'Bluetooth')."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Name of the application or Windows setting to launch.",
                    }
                },
                "required": ["app_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_installed_apps",
            "description": "List installed Windows Start Menu programs, optionally filtered by keyword.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filter_query": {
                        "type": "string",
                        "description": "Optional keyword to filter app names (pass empty string for all).",
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "play_youtube_video",
            "description": (
                "Find and immediately auto-play a specific song or video on YouTube (opens the direct watch URL, "
                "not just search results), optionally inside a specific browser like Brave, Chrome, Edge, or Firefox."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Song title, artist, or video name to play (e.g. 'Channa Mereya').",
                    },
                    "browser": {
                        "type": "string",
                        "enum": ["default", "brave", "chrome", "edge", "firefox", "opera"],
                        "description": "Browser to play the video in (e.g. 'brave' if user says 'on Brave'). Defaults to 'default'.",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_website",
            "description": (
                "Open a website URL or search on YouTube, Google, GitHub, Reddit, or Wikipedia in a specific browser "
                "(Brave, Chrome, Edge, Firefox) or the default browser."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_query": {
                        "type": "string",
                        "description": "Full URL (e.g. 'youtube.com') or search phrase.",
                    },
                    "platform": {
                        "type": "string",
                        "enum": ["auto", "youtube", "google", "github", "reddit", "wikipedia"],
                        "description": "Target site when searching. Use 'auto' for direct URLs or general Google searches.",
                    },
                    "browser": {
                        "type": "string",
                        "enum": ["default", "brave", "chrome", "edge", "firefox", "opera"],
                        "description": "Optional specific browser to open the URL in (e.g. 'brave', 'chrome').",
                    },
                },
                "required": ["url_or_query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "control_media_and_volume",
            "description": "Control Windows system volume, mute state, or media playback (play/pause, next/previous track).",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": [
                            "volume_up",
                            "volume_down",
                            "set_volume",
                            "mute_toggle",
                            "play_pause",
                            "next_track",
                            "prev_track",
                            "stop_media",
                        ],
                    },
                    "value": {
                        "type": "integer",
                        "description": "Percentage step (for volume_up/volume_down, default 10) or target 0-100 level (for set_volume).",
                    },
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "set_screen_brightness",
            "description": "Set laptop/integrated screen brightness percentage (5 to 100).",
            "parameters": {
                "type": "object",
                "properties": {
                    "percent": {
                        "type": "integer",
                        "description": "Brightness level from 5 to 100.",
                    }
                },
                "required": ["percent"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_pc_health_report",
            "description": (
                "Check CPU %, RAM usage, available disk space, battery status, JARVIS's own RAM footprint, "
                "and the top memory-hogging background apps on this PC."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "include_processes": {
                        "type": "boolean",
                        "description": "Include top memory-consuming processes (default true).",
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "boost_potato_ram",
            "description": (
                "Free up active RAM on a low-spec/potato Windows PC by safely trimming idle background "
                "working sets without closing or crashing any open apps."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "mode": {
                        "type": "string",
                        "description": "Optional optimization mode ('safe' default).",
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "close_application",
            "description": "Close/quit a specific non-system application by name to free CPU/RAM (only when user asks to close it).",
            "parameters": {
                "type": "object",
                "properties": {
                    "app_name": {
                        "type": "string",
                        "description": "Name of the user application to close (e.g. 'Discord', 'Spotify').",
                    }
                },
                "required": ["app_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_screen",
            "description": (
                "Capture what is currently visible on the user's Windows screen and analyze it with Free Cloud Vision "
                "(use when the user asks 'what is on my screen?', 'help fix this error', 'explain this page/code', etc.)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "Specific question or aspect of the screen to examine.",
                    }
                },
                "required": ["question"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Save a full-resolution PNG screenshot of the screen into Pictures/Jarvis_Screenshots.",
            "parameters": {
                "type": "object",
                "properties": {
                    "label": {
                        "type": "string",
                        "description": "Optional short filename tag.",
                    }
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "clipboard_tool",
            "description": "Read text currently copied in the Windows clipboard, or copy new text into the clipboard.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["read", "write"],
                    },
                    "text": {
                        "type": "string",
                        "description": "Text to copy to clipboard when action is 'write'.",
                    },
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "system_desktop_action",
            "description": "Execute safe Windows desktop actions: minimize_all (Win+D), lock_pc, empty_recycle_bin, or task_manager.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["minimize_all", "lock_pc", "empty_recycle_bin", "task_manager"],
                    }
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_user_files",
            "description": "Search for local files or folders by name inside Desktop, Downloads, Documents, or Pictures.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Filename or keyword to search."},
                    "folder": {
                        "type": "string",
                        "enum": ["all", "desktop", "downloads", "documents", "pictures"],
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_file_or_folder",
            "description": "Open a specific local file or directory path in its default Windows app or File Explorer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Full or ~ path to file or folder."}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_the_web",
            "description": "Search the live web for current events, facts, prices, guides, or news.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Web search query."}
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_live_weather",
            "description": "Get live current weather conditions and temperature for any city.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string", "description": "City name (e.g. 'Vijayawada', 'London')."}
                },
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "manage_memory",
            "description": "Save or forget personal facts/preferences about the user in persistent long-term memory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["remember", "forget", "list"]},
                    "text": {"type": "string", "description": "Fact to remember or keyword to forget."},
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "manage_todos",
            "description": "Add, complete, list, or clear completed items in the user's persistent to-do list.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["add", "complete", "list", "clear_completed"]},
                    "task": {"type": "string", "description": "Task text (for add) or task ID/keyword (for complete)."},
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "manage_notes",
            "description": "Save a quick persistent note or retrieve saved notes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["save", "read"]},
                    "title": {"type": "string", "description": "Short note title (for save) or search filter (for read)."},
                    "content": {"type": "string", "description": "Note body text (for save)."},
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "manage_timers",
            "description": "Start, list, or cancel countdown voice timers (e.g. 'set a timer for 5 minutes').",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["start", "list", "cancel_all"]},
                    "seconds": {"type": "integer", "description": "Duration in seconds when starting a timer."},
                    "label": {"type": "string", "description": "Label for the timer (e.g. 'Tea', 'Break')."},
                },
                "required": ["action"],
            },
        },
    },
]


def execute_tool_call(
    name: str,
    raw_args: str,
    *,
    config: JarvisConfig,
    memory: JarvisMemory,
    on_tool_activity: Optional[Callable[[str], None]] = None,
) -> str:
    """Safely parse tool JSON arguments and invoke the corresponding local/cloud tool."""
    try:
        args = json.loads(raw_args) if raw_args else {}
        if not isinstance(args, dict):
            args = {}
    except Exception:
        args = {}

    if on_tool_activity:
        on_tool_activity(name)

    try:
        if name == "open_application":
            return windows_control.open_application(args.get("app_name", ""))
        if name == "list_installed_apps":
            return windows_control.list_installed_apps(args.get("filter_query", ""))
        if name == "play_youtube_video":
            return windows_control.play_youtube_video(
                args.get("query", ""), args.get("browser", "default")
            )
        if name == "open_website":
            return windows_control.open_website(
                args.get("url_or_query", ""),
                args.get("platform", "auto"),
                args.get("browser", "default"),
            )
        if name == "control_media_and_volume":
            return windows_control.control_media_and_volume(
                args.get("action", ""), int(args.get("value") or 10)
            )
        if name == "set_screen_brightness":
            return windows_control.set_screen_brightness(int(args.get("percent") or 70))
        if name == "get_pc_health_report":
            return system_guard.get_pc_health_report()
        if name == "boost_potato_ram":
            return system_guard.boost_potato_ram()
        if name == "close_application":
            return system_guard.close_application_processes(args.get("app_name", ""))
        if name == "analyze_screen":
            return vision.inspect_screen_with_cloud_vision(
                args.get("question", ""), config
            )
        if name == "take_screenshot":
            return vision.save_screenshot_file(args.get("label", ""))
        if name == "clipboard_tool":
            return windows_control.clipboard_tool(
                args.get("action", "read"), args.get("text", "")
            )
        if name == "system_desktop_action":
            return windows_control.system_desktop_action(args.get("action", ""))
        if name == "search_user_files":
            return windows_control.search_user_files(
                args.get("query", ""), args.get("folder", "all")
            )
        if name == "open_file_or_folder":
            return windows_control.open_file_or_folder(args.get("path", ""))
        if name == "search_the_web":
            return web_tools.search_the_web(args.get("query", ""))
        if name == "get_live_weather":
            return web_tools.get_live_weather(args.get("city", ""))

        if name == "manage_memory":
            act = args.get("action", "list")
            if act == "remember":
                return memory.remember_fact(args.get("text", ""))
            if act == "forget":
                return memory.forget_fact(args.get("text", ""))
            facts = memory.list_facts()
            return "Stored facts:\n- " + "\n- ".join(facts) if facts else "No stored facts yet."

        if name == "manage_todos":
            act = args.get("action", "list")
            if act == "add":
                return memory.add_todo(args.get("task", ""))
            if act == "complete":
                return memory.complete_todo(args.get("task", ""))
            if act == "clear_completed":
                return memory.clear_completed_todos()
            return memory.list_todos_formatted()

        if name == "manage_notes":
            act = args.get("action", "read")
            if act == "save":
                return memory.save_note(args.get("title", "Note"), args.get("content", ""))
            return memory.get_notes_formatted(args.get("title", ""))

        if name == "manage_timers":
            act = args.get("action", "list")
            if act == "start":
                return memory.start_timer(
                    int(args.get("seconds") or 60), args.get("label", "Timer")
                )
            if act == "cancel_all":
                return memory.cancel_all_timers()
            return memory.list_timers_formatted()

        return f"Unknown tool '{name}'."
    except Exception as exc:
        return f"Tool '{name}' encountered an error: {exc}"
