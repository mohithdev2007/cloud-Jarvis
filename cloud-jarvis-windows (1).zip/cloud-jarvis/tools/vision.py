"""Ultra-fast Free Cloud Screen Vision & Screenshot Capture (Gemini Free + Groq Vision)."""

from __future__ import annotations

import base64
import io
from datetime import datetime
from typing import Optional

from core.config import SCREENSHOT_DIR, JarvisConfig
from core.providers import build_cloud_client, resolve_vision_models


def capture_screen_jpeg_b64(max_width: int = 1280, quality: int = 78) -> str:
    """Capture primary monitor and compress to an ~80KB base64 JPEG in memory."""
    import mss
    from PIL import Image

    with mss.mss() as sct:
        monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
        raw_shot = sct.grab(monitor)
        img = Image.frombytes("RGB", raw_shot.size, raw_shot.bgra, "raw", "BGRX")

    if img.width > max_width:
        ratio = max_width / float(img.width)
        new_size = (max_width, max(1, int(img.height * ratio)))
        img = img.resize(new_size, Image.Resampling.BILINEAR)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality, optimize=True)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def save_screenshot_file(custom_label: str = "") -> str:
    """Save a full-resolution PNG screenshot to ~/Pictures/Jarvis_Screenshots/."""
    import mss
    import mss.tools

    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_tag = "".join(c for c in custom_label if c.isalnum() or c in ("-", "_"))[:24]
    filename = f"jarvis_{stamp}{'_' + safe_tag if safe_tag else ''}.png"
    out_path = SCREENSHOT_DIR / filename

    with mss.mss() as sct:
        monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
        shot = sct.grab(monitor)
        mss.tools.to_png(shot.rgb, shot.size, output=str(out_path))

    return f"Saved screenshot to: {out_path}"


def inspect_screen_with_cloud_vision(question: str, config: JarvisConfig) -> str:
    """Capture current Windows screen and inspect it using Free Gemini / Groq Vision."""
    prompt = (
        (question or "").strip()
        or "Describe what is currently on my screen and highlight any important details or errors."
    )
    b64_jpeg = capture_screen_jpeg_b64()

    # Prefer Gemini first for Vision if available (top-tier OCR & UI reasoning), then Groq Llama-4 Vision
    providers = config.active_providers_ordered()
    providers_vision_sorted = sorted(
        providers, key=lambda item: 0 if item[0] == "gemini" else 1
    )

    last_err: Optional[Exception] = None
    for provider_name, api_key in providers_vision_sorted:
        client = build_cloud_client(provider_name, api_key, timeout=35.0)
        models = resolve_vision_models(provider_name, client, config.vision_model)
        for model_name in models[:3]:
            try:
                resp = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are JARVIS's visual cortex inspecting the user's Windows screen. "
                                "Give a clear, accurate, concise answer about visible text, errors, UI buttons, or code."
                            ),
                        },
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/jpeg;base64,{b64_jpeg}",
                                    },
                                },
                            ],
                        },
                    ],
                )
                return (resp.choices[0].message.content or "").strip()
            except Exception as exc:
                last_err = exc
                continue

    return f"Screen vision failed: {last_err}"
