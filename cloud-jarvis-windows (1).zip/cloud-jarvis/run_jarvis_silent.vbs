' Zero-console-window background launcher for Cloud J.A.R.V.I.S.
' Tip: Create a shortcut to this file in shell:startup (Win+R -> shell:startup) to start JARVIS with Windows!

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
pywPath = baseDir & "\.venv\Scripts\pythonw.exe"
scriptPath = baseDir & "\jarvis.py"

If fso.FileExists(pywPath) Then
    shell.CurrentDirectory = baseDir
    shell.Run """" & pywPath & """ """ & scriptPath & """", 0, False
Else
    shell.Run """" & baseDir & "\install_and_run.bat""", 1, False
End If
