"""Ultra-lean Terminal Mode (--cli) — 100% Free Cloud Edition for extreme potato PCs."""

from __future__ import annotations

import ctypes
import getpass
import sys

from core.brain import verify_api_key
from core.config import JarvisConfig
from core.controller import JarvisController
from tools import system_guard

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
DIM = "\033[90m"
RESET = "\033[0m"


def _enable_windows_ansi() -> None:
    if sys.platform != "win32":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


def run_cli_mode(config: JarvisConfig) -> None:
    _enable_windows_ansi()
    cpu, ram, own_mb = system_guard.get_live_hud_metrics()

    print(f"\n{CYAN}============================================================{RESET}")
    print(f"{CYAN}  ◉ J.A.R.V.I.S. FREE CLOUD — POTATO-PC TERMINAL EDITION{RESET}")
    print(f"{DIM}  $0 Cost | Footprint: {own_mb:.1f} MB RAM | 0% GPU | System RAM: {ram:.0f}%{RESET}")
    print(f"{CYAN}============================================================{RESET}")

    if not config.has_valid_key:
        print(f"\n{YELLOW}[100% Free Setup — No Credit Card Needed]{RESET}")
        print("  Get a FREE Google Gemini key -> https://aistudio.google.com/apikey")
        print("  OR a FREE Groq key          -> https://console.groq.com/keys\n")
        entered = getpass.getpass("Paste your FREE Gemini (AIza...) or Groq (gsk_...) key: ").strip()
        if entered:
            ok, msg, _prov, env_var = verify_api_key(entered)
            print(f"  -> {msg}")
            if ok and env_var:
                config.save_updates({env_var: entered})

    def _on_msg(role: str, text: str) -> None:
        if role == "jarvis":
            print(f"\n{CYAN}JARVIS:{RESET} {text}\n")
        elif role == "user" and text.startswith("🎙"):
            print(f"\n{GREEN}You:{RESET} {text}")
        elif role == "system":
            print(f"\n{YELLOW}[System]{RESET} {text}\n")

    def _on_state(state: str, detail: str) -> None:
        if state in {"listening", "thinking"} and detail:
            print(f"{DIM}  [{state.upper()}] {detail}{RESET}")

    controller = JarvisController(
        config=config,
        on_message=_on_msg,
        on_state_change=_on_state,
    )
    controller.start_background_services()

    print(
        f"\n{DIM}Commands:{RESET}\n"
        f"  • Press {GREEN}Enter{RESET} (empty line) or {GREEN}Alt+J / F9{RESET} -> Speak with microphone ($0)\n"
        f"  • Type any message + Enter            -> Chat / Control PC\n"
        f"  • {MAGENTA}/vision [question]{RESET}                  -> Inspect current Windows screen\n"
        f"  • {GREEN}/boost{RESET}                              -> Free idle Potato-PC RAM\n"
        f"  • {GREEN}/health{RESET}                             -> Detailed CPU/RAM hog report\n"
        f"  • {GREEN}/hf{RESET}                                 -> Toggle Hands-Free ('{config.wake_word}')\n"
        f"  • {GREEN}/mute{RESET}                               -> Toggle spoken TTS audio\n"
        f"  • {GREEN}/quit{RESET}                               -> Exit JARVIS\n"
    )

    try:
        while True:
            try:
                raw = input(f"{GREEN}You > {RESET}").strip()
            except EOFError:
                break

            if not raw:
                controller._ptt_worker()
                continue

            cmd = raw.lower()
            if cmd in {"/quit", "/exit", "exit", "quit"}:
                break
            if cmd == "/boost":
                print(f"\n{GREEN}⚡ {system_guard.boost_potato_ram()}{RESET}\n")
                continue
            if cmd == "/health":
                print(f"\n{system_guard.get_pc_health_report()}\n")
                continue
            if cmd == "/hf":
                on = controller.toggle_hands_free()
                print(f"{YELLOW}Hands-Free mode: {'ENABLED' if on else 'DISABLED'}{RESET}")
                continue
            if cmd == "/mute":
                config.speak_responses = not config.speak_responses
                config.save_updates(
                    {"JARVIS_SPEAK_RESPONSES": str(config.speak_responses).lower()}
                )
                print(
                    f"{YELLOW}Spoken voice replies: {'ON' if config.speak_responses else 'MUTED'}{RESET}"
                )
                continue
            if cmd.startswith("/vision"):
                q = raw[7:].strip() or "Analyze what is currently visible on my screen."
                controller._run_text_turn(q, attach_screen=True)
                continue

            controller._run_text_turn(raw, attach_screen=False)
    except KeyboardInterrupt:
        print(f"\n{DIM}Shutting down JARVIS...{RESET}")
    finally:
        controller.shutdown()
