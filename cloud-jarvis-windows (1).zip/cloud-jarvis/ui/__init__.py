"""User interface modules for Cloud JARVIS (Floating HUD + Lean CLI)."""
