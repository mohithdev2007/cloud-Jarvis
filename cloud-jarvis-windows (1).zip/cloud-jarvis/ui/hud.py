"""Ultra-lightweight Floating Arc-Reactor HUD for Windows (100% Free Cloud Edition, 0% idle CPU)."""

from __future__ import annotations

import math
import sys
import threading
import tkinter as tk
import webbrowser
from tkinter import ttk
from typing import Dict, Optional

from core.audio_engine import FREE_NEURAL_VOICES
from core.brain import verify_api_key
from core.config import JarvisConfig
from core.controller import JarvisController
from tools import system_guard

BG_MAIN = "#080D16"
BG_PANEL = "#0E1624"
BG_INPUT = "#131E30"
BORDER_CYAN = "#164E63"
ACCENT_CYAN = "#00E5FF"
ACCENT_GREEN = "#10B981"
ACCENT_AMBER = "#F59E0B"
ACCENT_VIOLET = "#A855F7"
TEXT_PRIMARY = "#E2E8F0"
TEXT_MUTED = "#7DD3FC"
TEXT_DIM = "#64748B"
DANGER_RED = "#EF4444"

STATE_COLORS = {
    "idle": ACCENT_CYAN,
    "listening": ACCENT_GREEN,
    "thinking": ACCENT_AMBER,
    "speaking": ACCENT_VIOLET,
}


class JarvisFloatingHUD:
    """Compact corner HUD overlay with 0% idle CPU animation & expandable chat drawer."""

    COMPACT_W = 400
    COMPACT_H = 148
    EXPANDED_H = 490

    def __init__(self, config: JarvisConfig) -> None:
        self.config = config
        self.root = tk.Tk()
        self.root.title("J.A.R.V.I.S. Free Cloud")
        self.root.configure(bg=BG_MAIN)
        self.root.overrideredirect(True)

        if sys.platform == "win32":
            try:
                self.root.attributes("-alpha", 0.95)
            except Exception:
                pass
        try:
            self.root.attributes("-topmost", self.config.always_on_top)
        except Exception:
            pass

        self._expanded = False
        self._drag_x = 0
        self._drag_y = 0
        self._anim_phase = 0.0
        self._audio_level = 0.0
        self._anim_job: Optional[str] = None
        self._current_state = "idle"

        self.controller = JarvisController(
            config=self.config,
            on_state_change=self._threadsafe_state_change,
            on_message=self._threadsafe_message,
            on_audio_level=self._threadsafe_level,
            on_hands_free_change=self._threadsafe_hf_change,
        )

        self._build_ui()
        self._position_bottom_right()
        self._draw_arc_reactor()
        self._poll_system_metrics()

        self.root.protocol("WM_DELETE_WINDOW", self.quit_app)

    def _position_bottom_right(self) -> None:
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        h = self.EXPANDED_H if self._expanded else self.COMPACT_H
        x = max(16, sw - self.COMPACT_W - 22)
        y = max(16, sh - h - 58)
        self.root.geometry(f"{self.COMPACT_W}x{h}+{x}+{y}")

    def _build_ui(self) -> None:
        self.outer = tk.Frame(
            self.root,
            bg=BG_MAIN,
            highlightbackground=BORDER_CYAN,
            highlightthickness=1,
        )
        self.outer.pack(fill=tk.BOTH, expand=True)

        # ---- Top Draggable Header Bar ----
        header = tk.Frame(self.outer, bg=BG_PANEL, height=28)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        title_lbl = tk.Label(
            header,
            text="◉ J.A.R.V.I.S. FREE",
            fg=ACCENT_CYAN,
            bg=BG_PANEL,
            font=("Consolas", 9, "bold"),
            cursor="fleur",
        )
        title_lbl.pack(side=tk.LEFT, padx=(8, 4))

        self.metrics_lbl = tk.Label(
            header,
            text="CPU --% | RAM --%",
            fg=TEXT_DIM,
            bg=BG_PANEL,
            font=("Consolas", 8),
            cursor="fleur",
        )
        self.metrics_lbl.pack(side=tk.LEFT, padx=2)

        for widget in (header, title_lbl, self.metrics_lbl):
            widget.bind("<ButtonPress-1>", self._on_drag_start)
            widget.bind("<B1-Motion>", self._on_drag_motion)

        btn_close = tk.Button(
            header,
            text="✕",
            command=self.quit_app,
            bg=BG_PANEL,
            fg=TEXT_DIM,
            activebackground=DANGER_RED,
            activeforeground="#FFFFFF",
            bd=0,
            font=("Segoe UI", 9, "bold"),
            padx=6,
            cursor="hand2",
        )
        btn_close.pack(side=tk.RIGHT)

        btn_min = tk.Button(
            header,
            text="—",
            command=self._minimize_to_taskbar,
            bg=BG_PANEL,
            fg=TEXT_DIM,
            activebackground=BG_INPUT,
            activeforeground=TEXT_PRIMARY,
            bd=0,
            font=("Segoe UI", 9),
            padx=5,
            cursor="hand2",
        )
        btn_min.pack(side=tk.RIGHT)

        btn_gear = tk.Button(
            header,
            text="⚙",
            command=self.open_settings_modal,
            bg=BG_PANEL,
            fg=TEXT_MUTED,
            activebackground=BG_INPUT,
            activeforeground=ACCENT_CYAN,
            bd=0,
            font=("Segoe UI", 9),
            padx=5,
            cursor="hand2",
        )
        btn_gear.pack(side=tk.RIGHT)

        btn_boost = tk.Button(
            header,
            text="⚡RAM",
            command=self._quick_ram_boost,
            bg=BG_PANEL,
            fg=ACCENT_GREEN,
            activebackground=BG_INPUT,
            activeforeground=ACCENT_CYAN,
            bd=0,
            font=("Consolas", 8, "bold"),
            padx=4,
            cursor="hand2",
        )
        btn_boost.pack(side=tk.RIGHT, padx=2)

        # ---- Main Compact Core Row ----
        core_row = tk.Frame(self.outer, bg=BG_MAIN, pady=6, padx=10)
        core_row.pack(fill=tk.X)

        self.orb_canvas = tk.Canvas(
            core_row,
            width=58,
            height=58,
            bg=BG_MAIN,
            highlightthickness=0,
            cursor="hand2",
        )
        self.orb_canvas.pack(side=tk.LEFT, padx=(0, 10))
        self.orb_canvas.bind("<Button-1>", lambda _e: self.controller.trigger_push_to_talk())

        info_col = tk.Frame(core_row, bg=BG_MAIN)
        info_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.state_badge = tk.Label(
            info_col,
            text="IDLE // $0 FREE CLOUD",
            fg=ACCENT_CYAN,
            bg=BG_MAIN,
            anchor="w",
            font=("Consolas", 9, "bold"),
        )
        self.state_badge.pack(fill=tk.X)

        self.subtitle_lbl = tk.Label(
            info_col,
            text="Press Alt+J, F9, or click Orb to speak",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            anchor="w",
            justify=tk.LEFT,
            wraplength=305,
            font=("Segoe UI", 9),
        )
        self.subtitle_lbl.pack(fill=tk.X, pady=(2, 0))

        # ---- Compact Action Buttons Bar ----
        actions_bar = tk.Frame(self.outer, bg=BG_MAIN, padx=8, pady=4)
        actions_bar.pack(fill=tk.X)

        self.ptt_btn = tk.Button(
            actions_bar,
            text="🎙 Speak (Alt+J)",
            command=self.controller.trigger_push_to_talk,
            bg="#0C2D48",
            fg=ACCENT_CYAN,
            activebackground="#145374",
            activeforeground="#FFFFFF",
            bd=0,
            padx=9,
            pady=4,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        )
        self.ptt_btn.pack(side=tk.LEFT, padx=(0, 4))

        self.hf_btn = tk.Button(
            actions_bar,
            text="Hands-Free: OFF",
            command=self.controller.toggle_hands_free,
            bg=BG_INPUT,
            fg=TEXT_DIM,
            activebackground=BG_PANEL,
            activeforeground=ACCENT_GREEN,
            bd=0,
            padx=8,
            pady=4,
            font=("Segoe UI", 8),
            cursor="hand2",
        )
        self.hf_btn.pack(side=tk.LEFT, padx=3)

        vision_btn = tk.Button(
            actions_bar,
            text="👁 Vision",
            command=self.controller.trigger_screen_vision,
            bg=BG_INPUT,
            fg=TEXT_MUTED,
            activebackground=BG_PANEL,
            activeforeground=ACCENT_CYAN,
            bd=0,
            padx=8,
            pady=4,
            font=("Segoe UI", 8),
            cursor="hand2",
        )
        vision_btn.pack(side=tk.LEFT, padx=3)

        self.voice_btn = tk.Button(
            actions_bar,
            text="🔊" if self.config.speak_responses else "🔇",
            command=self._toggle_voice_mute,
            bg=BG_INPUT,
            fg=ACCENT_CYAN if self.config.speak_responses else TEXT_DIM,
            bd=0,
            padx=6,
            pady=4,
            font=("Segoe UI", 8),
            cursor="hand2",
        )
        self.voice_btn.pack(side=tk.LEFT, padx=3)

        self.drawer_btn = tk.Button(
            actions_bar,
            text="▲ Chat",
            command=self.toggle_drawer,
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            activebackground=BG_PANEL,
            activeforeground=ACCENT_CYAN,
            bd=0,
            padx=8,
            pady=4,
            font=("Segoe UI", 8),
            cursor="hand2",
        )
        self.drawer_btn.pack(side=tk.RIGHT)

        # ---- Expandable Chat & Text Command Drawer ----
        self.drawer_frame = tk.Frame(self.outer, bg=BG_MAIN, padx=8, pady=4)

        chat_container = tk.Frame(
            self.drawer_frame,
            bg=BG_PANEL,
            highlightbackground="#1E293B",
            highlightthickness=1,
        )
        chat_container.pack(fill=tk.BOTH, expand=True, pady=(2, 6))

        scrollbar = ttk.Scrollbar(chat_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.chat_box = tk.Text(
            chat_container,
            bg=BG_PANEL,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            selectbackground="#1E3A8A",
            bd=0,
            padx=8,
            pady=6,
            wrap=tk.WORD,
            font=("Segoe UI", 9),
            state=tk.DISABLED,
            yscrollcommand=scrollbar.set,
        )
        self.chat_box.pack(fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.chat_box.yview)

        self.chat_box.tag_configure("user", foreground="#38BDF8", font=("Segoe UI", 9, "bold"))
        self.chat_box.tag_configure("jarvis", foreground="#E2E8F0", font=("Segoe UI", 9))
        self.chat_box.tag_configure("jarvis_tag", foreground=ACCENT_CYAN, font=("Consolas", 9, "bold"))
        self.chat_box.tag_configure("system", foreground=ACCENT_AMBER, font=("Segoe UI", 8, "italic"))

        entry_row = tk.Frame(self.drawer_frame, bg=BG_MAIN)
        entry_row.pack(fill=tk.X, pady=(0, 4))

        self.input_var = tk.StringVar()
        self.input_entry = tk.Entry(
            entry_row,
            textvariable=self.input_var,
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            relief=tk.FLAT,
            font=("Segoe UI", 9),
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=5, padx=(0, 5))
        self.input_entry.bind("<Return>", lambda _e: self._send_typed(attach_screen=False))

        send_screen_btn = tk.Button(
            entry_row,
            text="👁+",
            command=lambda: self._send_typed(attach_screen=True),
            bg=BG_INPUT,
            fg=TEXT_MUTED,
            bd=0,
            padx=7,
            pady=5,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        )
        send_screen_btn.pack(side=tk.LEFT, padx=(0, 4))

        send_btn = tk.Button(
            entry_row,
            text="Send",
            command=lambda: self._send_typed(attach_screen=False),
            bg="#0C2D48",
            fg=ACCENT_CYAN,
            bd=0,
            padx=10,
            pady=5,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        )
        send_btn.pack(side=tk.RIGHT)

        self._update_hf_button(self.config.hands_free_default)

    # ---- Dragging & Window Management ----
    def _on_drag_start(self, event: tk.Event) -> None:
        self._drag_x = event.x_root - self.root.winfo_x()
        self._drag_y = event.y_root - self.root.winfo_y()

    def _on_drag_motion(self, event: tk.Event) -> None:
        nx = event.x_root - self._drag_x
        ny = event.y_root - self._drag_y
        self.root.geometry(f"+{nx}+{ny}")

    def _minimize_to_taskbar(self) -> None:
        self.root.overrideredirect(False)
        self.root.iconify()

        def _restore_frame(_event: tk.Event) -> None:
            if self.root.state() == "normal":
                self.root.unbind("<Map>")
                self.root.overrideredirect(True)
                try:
                    self.root.attributes("-topmost", self.config.always_on_top)
                except Exception:
                    pass

        self.root.bind("<Map>", _restore_frame)

    def toggle_drawer(self) -> None:
        cur_x = self.root.winfo_x()
        cur_y = self.root.winfo_y()
        cur_h = self.root.winfo_height()
        bottom_y = cur_y + cur_h

        self._expanded = not self._expanded
        if self._expanded:
            self.drawer_frame.pack(fill=tk.BOTH, expand=True)
            self.drawer_btn.config(text="▼ Compact")
            new_h = self.EXPANDED_H
            self.input_entry.focus_set()
        else:
            self.drawer_frame.pack_forget()
            self.drawer_btn.config(text="▲ Chat")
            new_h = self.COMPACT_H

        new_y = max(10, bottom_y - new_h)
        self.root.geometry(f"{self.COMPACT_W}x{new_h}+{cur_x}+{new_y}")

    # ---- Zero-Idle-CPU Arc Reactor Renderer ----
    def _draw_arc_reactor(self) -> None:
        c = self.orb_canvas
        c.delete("all")
        cx, cy = 29, 29
        color = STATE_COLORS.get(self._current_state, ACCENT_CYAN)

        c.create_oval(4, 4, 54, 54, outline="#1E293B", width=2)

        boost = self._audio_level * 9.0
        if self._current_state == "thinking":
            boost = 3.5 + 3.0 * math.sin(self._anim_phase * 2.2)
        elif self._current_state == "listening" and boost < 1.5:
            boost = 2.0 + 1.5 * math.sin(self._anim_phase * 1.8)

        r_mid = min(25.0, 17.0 + boost)
        c.create_oval(
            cx - r_mid,
            cy - r_mid,
            cx + r_mid,
            cy + r_mid,
            outline=color,
            width=2,
        )

        deg_offset = int((self._anim_phase * 45) % 360)
        for base_angle in (0, 120, 240):
            c.create_arc(
                7,
                7,
                51,
                51,
                start=base_angle + deg_offset,
                extent=55,
                style=tk.ARC,
                outline=color,
                width=2,
            )

        r_core = min(13.0, 8.0 + boost * 0.45)
        c.create_oval(
            cx - r_core,
            cy - r_core,
            cx + r_core,
            cy + r_core,
            fill=color,
            outline="",
        )

    def _schedule_animation_if_active(self) -> None:
        if self._current_state == "idle":
            if self._anim_job is not None:
                self.root.after_cancel(self._anim_job)
                self._anim_job = None
            self._audio_level = 0.0
            self._draw_arc_reactor()
            return

        if self._anim_job is None:
            self._tick_animation()

    def _tick_animation(self) -> None:
        self._anim_job = None
        if self._current_state == "idle":
            self._draw_arc_reactor()
            return
        self._anim_phase += 0.24
        self._draw_arc_reactor()
        self._anim_job = self.root.after(66, self._tick_animation)

    def _poll_system_metrics(self) -> None:
        try:
            cpu, ram, own_mb = system_guard.get_live_hud_metrics()
            ram_warn = "!" if ram >= 85 else ""
            self.metrics_lbl.config(
                text=f"CPU {cpu:.0f}% | RAM {ram:.0f}%{ram_warn} ({own_mb:.0f}MB)",
                fg=ACCENT_AMBER if ram >= 85 else TEXT_DIM,
            )
        except Exception:
            pass
        self.root.after(4000, self._poll_system_metrics)

    # ---- Controller Callbacks ----
    def _threadsafe_state_change(self, state: str, detail: str) -> None:
        self.root.after(0, lambda: self._apply_state(state, detail))

    def _apply_state(self, state: str, detail: str) -> None:
        self._current_state = state
        color = STATE_COLORS.get(state, ACCENT_CYAN)
        labels = {
            "idle": "IDLE // $0 FREE CLOUD",
            "listening": "LISTENING // SPEAK NOW",
            "thinking": "FREE CLOUD // PROCESSING",
            "speaking": "SPEAKING // NEURAL VOICE",
        }
        self.state_badge.config(text=labels.get(state, state.upper()), fg=color)
        if detail:
            self.subtitle_lbl.config(text=detail)

        if state == "listening":
            self.ptt_btn.config(text="⏹ Done Speaking", bg="#064E3B", fg="#A7F3D0")
        elif state == "speaking":
            self.ptt_btn.config(text="⏹ Interrupt", bg="#3B0764", fg="#E9D5FF")
        else:
            self.ptt_btn.config(text="🎙 Speak (Alt+J)", bg="#0C2D48", fg=ACCENT_CYAN)

        self._schedule_animation_if_active()

    def _threadsafe_level(self, level: float) -> None:
        self._audio_level = level

    def _threadsafe_hf_change(self, enabled: bool) -> None:
        self.root.after(0, lambda: self._update_hf_button(enabled))

    def _update_hf_button(self, enabled: bool) -> None:
        if enabled:
            self.hf_btn.config(text="Hands-Free: ON", fg=ACCENT_GREEN, bg="#063328")
        else:
            self.hf_btn.config(text="Hands-Free: OFF", fg=TEXT_DIM, bg=BG_INPUT)

    def _threadsafe_message(self, role: str, text: str) -> None:
        self.root.after(0, lambda: self._append_chat(role, text))

    def _append_chat(self, role: str, text: str) -> None:
        if role in {"jarvis", "system"}:
            preview = text.replace("\n", " ").strip()
            if len(preview) > 92:
                preview = preview[:92] + "..."
            self.subtitle_lbl.config(text=preview)

        self.chat_box.config(state=tk.NORMAL)
        if role == "user":
            self.chat_box.insert(tk.END, f"You: {text}\n\n", "user")
        elif role == "jarvis":
            self.chat_box.insert(tk.END, "JARVIS: ", "jarvis_tag")
            self.chat_box.insert(tk.END, f"{text}\n\n", "jarvis")
        else:
            self.chat_box.insert(tk.END, f"[System] {text}\n\n", "system")
        self.chat_box.see(tk.END)
        self.chat_box.config(state=tk.DISABLED)

    def _send_typed(self, attach_screen: bool = False) -> None:
        txt = self.input_var.get().strip()
        if not txt and not attach_screen:
            return
        self.input_var.set("")
        self.controller.submit_text_async(txt, attach_screen=attach_screen)

    def _toggle_voice_mute(self) -> None:
        new_val = not self.config.speak_responses
        self.config.save_updates({"JARVIS_SPEAK_RESPONSES": str(new_val).lower()})
        if not new_val:
            self.controller.audio.interrupt_speech()
        self.voice_btn.config(
            text="🔊" if new_val else "🔇",
            fg=ACCENT_CYAN if new_val else TEXT_DIM,
        )

    def _quick_ram_boost(self) -> None:
        def _run() -> None:
            report = system_guard.boost_potato_ram()
            self._threadsafe_message("system", f"⚡ {report}")

        threading.Thread(target=_run, daemon=True).start()

    # ---- 100% Free Cloud Setup & Settings Modal ----
    def open_settings_modal(self) -> None:
        win = tk.Toplevel(self.root)
        win.title("J.A.R.V.I.S. 100% Free Cloud Setup")
        win.configure(bg=BG_MAIN, padx=16, pady=14)
        win.geometry("465x475")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        tk.Label(
            win,
            text="◉ 100% FREE CLOUD J.A.R.V.I.S. ($0 / NO CARD)",
            fg=ACCENT_CYAN,
            bg=BG_MAIN,
            font=("Consolas", 10, "bold"),
        ).pack(anchor="w", pady=(0, 4))

        tk.Label(
            win,
            text="Step 1: Click either button below to grab a FREE API key (Google sign-in, no credit card):",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            wraplength=430,
            justify=tk.LEFT,
            font=("Segoe UI", 8),
        ).pack(anchor="w", pady=(0, 6))

        link_row = tk.Frame(win, bg=BG_MAIN)
        link_row.pack(fill=tk.X, pady=(0, 10))

        tk.Button(
            link_row,
            text="🔑 Get FREE Gemini Key (Recommended) ↗",
            command=lambda: webbrowser.open("https://aistudio.google.com/apikey"),
            bg="#064E3B",
            fg="#A7F3D0",
            bd=0,
            padx=9,
            pady=5,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(
            link_row,
            text="⚡ Get FREE Groq Key (500 tok/s) ↗",
            command=lambda: webbrowser.open("https://console.groq.com/keys"),
            bg="#0C2D48",
            fg=ACCENT_CYAN,
            bd=0,
            padx=9,
            pady=5,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        ).pack(side=tk.LEFT)

        tk.Label(
            win,
            text="Free Google Gemini Key (AIza... — Brain + Vision):",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            font=("Segoe UI", 9),
        ).pack(anchor="w")

        gemini_var = tk.StringVar(value=self.config.gemini_api_key)
        tk.Entry(
            win,
            textvariable=gemini_var,
            show="•",
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            relief=tk.FLAT,
            font=("Consolas", 9),
        ).pack(fill=tk.X, ipady=4, pady=(2, 8))

        tk.Label(
            win,
            text="Free Groq Key (gsk_... — Optional, adds 0.2s Whisper & 500 tok/s speed):",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            font=("Segoe UI", 9),
        ).pack(anchor="w")

        groq_var = tk.StringVar(value=self.config.groq_api_key)
        tk.Entry(
            win,
            textvariable=groq_var,
            show="•",
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            relief=tk.FLAT,
            font=("Consolas", 9),
        ).pack(fill=tk.X, ipady=4, pady=(2, 8))

        grid = tk.Frame(win, bg=BG_MAIN)
        grid.pack(fill=tk.X, pady=4)

        tk.Label(
            grid,
            text="Free Neural Voice ($0):",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            font=("Segoe UI", 9),
        ).grid(row=0, column=0, sticky="w", pady=4)

        voice_var = tk.StringVar(value=self.config.tts_voice)
        voice_menu = ttk.Combobox(
            grid,
            textvariable=voice_var,
            values=FREE_NEURAL_VOICES,
            state="readonly",
            width=25,
        )
        voice_menu.grid(row=0, column=1, sticky="e", padx=8, pady=4)

        tk.Label(
            grid,
            text="Address Me As:",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, sticky="w", pady=4)
        title_var = tk.StringVar(value=self.config.user_title)
        tk.Entry(
            grid,
            textvariable=title_var,
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            relief=tk.FLAT,
            width=28,
        ).grid(row=1, column=1, sticky="e", padx=8, pady=4, ipady=3)

        tk.Label(
            grid,
            text="Wake Word:",
            fg=TEXT_PRIMARY,
            bg=BG_MAIN,
            font=("Segoe UI", 9),
        ).grid(row=2, column=0, sticky="w", pady=4)
        wake_var = tk.StringVar(value=self.config.wake_word)
        tk.Entry(
            grid,
            textvariable=wake_var,
            bg=BG_INPUT,
            fg=TEXT_PRIMARY,
            insertbackground=ACCENT_CYAN,
            relief=tk.FLAT,
            width=28,
        ).grid(row=2, column=1, sticky="e", padx=8, pady=4, ipady=3)

        status_var = tk.StringVar(
            value="You only need ONE free key above (or paste both for double quota + auto-failover)."
        )
        status_lbl = tk.Label(
            win,
            textvariable=status_var,
            fg=TEXT_MUTED,
            bg=BG_MAIN,
            wraplength=430,
            justify=tk.LEFT,
            font=("Segoe UI", 8),
        )
        status_lbl.pack(anchor="w", pady=(8, 8))

        def _test_free_voice() -> None:
            self.config.tts_voice = voice_var.get().strip() or "en-GB-RyanNeural"
            threading.Thread(
                target=lambda: self.controller.audio.speak_text(
                    f"Good day, {title_var.get().strip() or 'sir'}. Free neural voice systems are online."
                ),
                daemon=True,
            ).start()

        def _save_and_verify() -> None:
            k1 = gemini_var.get().strip()
            k2 = groq_var.get().strip()
            entered_keys = [k for k in (k1, k2) if k]

            if not entered_keys:
                status_lbl.config(fg=DANGER_RED)
                status_var.set("Please paste at least ONE free key (click the green Gemini or cyan Groq button above!).")
                return

            status_lbl.config(fg=ACCENT_AMBER)
            status_var.set("Verifying Free Cloud key(s)...")
            win.update_idletasks()

            def _worker() -> None:
                updates: Dict[str, str] = {
                    "JARVIS_TTS_VOICE": voice_var.get().strip() or "en-GB-RyanNeural",
                    "JARVIS_USER_TITLE": title_var.get().strip() or "sir",
                    "JARVIS_WAKE_WORD": wake_var.get().strip().lower() or "jarvis",
                }
                verified_msgs = []
                for raw_k in entered_keys:
                    ok, msg, _prov, env_var = verify_api_key(raw_k)
                    if not ok:
                        self.root.after(
                            0,
                            lambda m=msg: (
                                status_lbl.config(fg=DANGER_RED),
                                status_var.set(m),
                            ),
                        )
                        return
                    updates[env_var] = raw_k
                    verified_msgs.append(msg)

                def _finish() -> None:
                    self.config.save_updates(updates)
                    self.controller.brain._clients.clear()
                    summary = " | ".join(verified_msgs)
                    status_lbl.config(fg=ACCENT_GREEN)
                    status_var.set(summary)
                    self._append_chat(
                        "system",
                        f"{summary} — Press Alt+J or F9 to talk for $0!",
                    )
                    win.after(800, win.destroy)

                self.root.after(0, _finish)

            threading.Thread(target=_worker, daemon=True).start()

        btn_row = tk.Frame(win, bg=BG_MAIN)
        btn_row.pack(fill=tk.X, pady=(4, 0))

        tk.Button(
            btn_row,
            text="🔊 Test Free Voice",
            command=_test_free_voice,
            bg=BG_INPUT,
            fg=ACCENT_GREEN,
            bd=0,
            padx=10,
            pady=6,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
        ).pack(side=tk.LEFT)

        tk.Button(
            btn_row,
            text="✔ Verify & Activate Free JARVIS",
            command=_save_and_verify,
            bg="#0C2D48",
            fg=ACCENT_CYAN,
            bd=0,
            padx=13,
            pady=6,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        ).pack(side=tk.RIGHT)

        tk.Button(
            btn_row,
            text="Cancel",
            command=win.destroy,
            bg=BG_INPUT,
            fg=TEXT_DIM,
            bd=0,
            padx=10,
            pady=6,
            font=("Segoe UI", 9),
            cursor="hand2",
        ).pack(side=tk.RIGHT, padx=6)

    def run(self) -> None:
        self.controller.start_background_services()
        self._append_chat(
            "jarvis",
            f"Online at $0 cost, {self.config.user_title}. All heavy AI runs in Free Cloud so your PC stays cool and fast.",
        )
        if not self.config.has_valid_key:
            self.root.after(250, self.open_settings_modal)
        self.root.mainloop()

    def quit_app(self) -> None:
        self.controller.shutdown()
        try:
            self.root.destroy()
        except Exception:
            sys.exit(0)
