"""Configuration loader & multi-provider free-key manager for Cloud JARVIS."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"
ENV_EXAMPLE_PATH = BASE_DIR / ".env.example"
DATA_DIR = BASE_DIR / "data"
SCREENSHOT_DIR = Path.home() / "Pictures" / "Jarvis_Screenshots"


def _parse_bool(val: str | None, default: bool = True) -> bool:
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _clean_key(raw: str | None) -> str:
    val = (raw or "").strip().strip('"').strip("'")
    if val.startswith(("sk-your-", "your-")):
        return ""
    return val


def detect_provider_from_key(api_key: str) -> Tuple[str, str]:
    """Return (provider_name, env_var_name) based on API key prefix."""
    k = _clean_key(api_key)
    if k.startswith("AIza"):
        return "gemini", "GEMINI_API_KEY"
    if k.startswith("gsk_"):
        return "groq", "GROQ_API_KEY"
    if k.startswith("sk-or-"):
        return "openrouter", "OPENROUTER_API_KEY"
    if k.startswith("sk-"):
        return "openai", "OPENAI_API_KEY"
    # Default fallback to Gemini if unrecognized format
    return "gemini", "GEMINI_API_KEY"


@dataclass
class JarvisConfig:
    gemini_api_key: str = ""
    groq_api_key: str = ""
    openrouter_api_key: str = ""
    openai_api_key: str = ""
    provider: str = "auto"
    chat_model: str = "auto"
    vision_model: str = "auto"
    tts_voice: str = "en-GB-RyanNeural"
    user_title: str = "sir"
    speak_responses: bool = True
    wake_word: str = "jarvis"
    language: str = "en"
    hands_free_default: bool = False
    always_on_top: bool = True
    max_history: int = 16

    @property
    def has_valid_key(self) -> bool:
        return any(
            len(k) >= 16
            for k in (
                self.gemini_api_key,
                self.groq_api_key,
                self.openrouter_api_key,
                self.openai_api_key,
            )
        )

    def active_providers_ordered(self) -> List[Tuple[str, str]]:
        """Return ordered list of (provider_slug, api_key) available for failover."""
        available: Dict[str, str] = {}
        if len(self.gemini_api_key) >= 16:
            available["gemini"] = self.gemini_api_key
        if len(self.groq_api_key) >= 16:
            available["groq"] = self.groq_api_key
        if len(self.openrouter_api_key) >= 16:
            available["openrouter"] = self.openrouter_api_key
        if len(self.openai_api_key) >= 16:
            available["openai"] = self.openai_api_key

        pref = (self.provider or "auto").lower()
        # In 'auto' mode, prefer Groq first if present (500 tok/s speed) with Gemini right behind,
        # or Gemini first if only Gemini is set.
        default_order = ["groq", "gemini", "openrouter", "openai"]
        if pref in available:
            ordered_names = [pref] + [p for p in default_order if p != pref]
        else:
            ordered_names = default_order

        return [(name, available[name]) for name in ordered_names if name in available]

    @classmethod
    def load(cls) -> "JarvisConfig":
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not ENV_PATH.exists() and ENV_EXAMPLE_PATH.exists():
            ENV_PATH.write_text(ENV_EXAMPLE_PATH.read_text(encoding="utf-8"), encoding="utf-8")
        load_dotenv(ENV_PATH, override=True)

        max_hist_raw = os.getenv("JARVIS_MAX_HISTORY", "16")
        try:
            max_hist = max(4, min(60, int(max_hist_raw)))
        except ValueError:
            max_hist = 16

        return cls(
            gemini_api_key=_clean_key(os.getenv("GEMINI_API_KEY")),
            groq_api_key=_clean_key(os.getenv("GROQ_API_KEY")),
            openrouter_api_key=_clean_key(os.getenv("OPENROUTER_API_KEY")),
            openai_api_key=_clean_key(os.getenv("OPENAI_API_KEY")),
            provider=os.getenv("JARVIS_PROVIDER", "auto").strip().lower() or "auto",
            chat_model=os.getenv("JARVIS_CHAT_MODEL", "auto").strip() or "auto",
            vision_model=os.getenv("JARVIS_VISION_MODEL", "auto").strip() or "auto",
            tts_voice=os.getenv("JARVIS_TTS_VOICE", "en-GB-RyanNeural").strip()
            or "en-GB-RyanNeural",
            user_title=os.getenv("JARVIS_USER_TITLE", "sir").strip() or "sir",
            speak_responses=_parse_bool(os.getenv("JARVIS_SPEAK_RESPONSES"), True),
            wake_word=os.getenv("JARVIS_WAKE_WORD", "jarvis").strip().lower() or "jarvis",
            language=os.getenv("JARVIS_LANGUAGE", "en").strip(),
            hands_free_default=_parse_bool(os.getenv("JARVIS_HANDS_FREE_DEFAULT"), False),
            always_on_top=_parse_bool(os.getenv("JARVIS_ALWAYS_ON_TOP"), True),
            max_history=max_hist,
        )

    def save_updates(self, updates: Dict[str, str]) -> None:
        """Persist updated key-value pairs into .env while keeping comments intact."""
        if not ENV_PATH.exists() and ENV_EXAMPLE_PATH.exists():
            ENV_PATH.write_text(ENV_EXAMPLE_PATH.read_text(encoding="utf-8"), encoding="utf-8")

        lines = ENV_PATH.read_text(encoding="utf-8").splitlines() if ENV_PATH.exists() else []
        remaining = dict(updates)
        new_lines = []

        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                key = stripped.split("=", 1)[0].strip()
                if key in remaining:
                    new_lines.append(f"{key}={remaining.pop(key)}")
                    continue
            new_lines.append(line)

        for key, val in remaining.items():
            new_lines.append(f"{key}={val}")

        ENV_PATH.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
        for key, val in updates.items():
            os.environ[key] = val

        refreshed = self.load()
        self.__dict__.update(refreshed.__dict__)
