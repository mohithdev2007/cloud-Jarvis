"""Zero-CPU, Zero-Admin Global Hotkeys for Windows using native Win32 RegisterHotKey.

Why Win32 RegisterHotKey instead of the `keyboard` pip package?
1. Sleeps inside the Windows kernel message queue (0.00% idle CPU).
2. Does NOT require Administrator privileges or trigger Defender keylogger alerts.
3. Zero external dependencies.
"""

from __future__ import annotations

import ctypes
import sys
import threading
from typing import Callable, Dict, List, Optional

# Win32 Modifier flags
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_NOREPEAT = 0x4000

WM_HOTKEY = 0x0312
WM_QUIT = 0x0012

# Virtual-Key Codes
VK_F9 = 0x78
VK_J = 0x4A
VK_S = 0x53
VK_H = 0x48
VK_X = 0x58


class GlobalHotkeyManager:
    """Registers OS-wide hotkeys on Windows; no-ops gracefully on non-Windows."""

    def __init__(self, callbacks: Dict[str, Callable[[], None]]) -> None:
        """
        callbacks keys:
          - 'ptt': Push-to-Talk / Tap-to-Talk
          - 'vision': Capture & Analyze Screen
          - 'hands_free': Toggle Hands-Free wake mode
          - 'interrupt': Stop speaking immediately
        """
        self._callbacks = callbacks
        self._thread: Optional[threading.Thread] = None
        self._thread_id: Optional[int] = None
        self._running = False
        self.registered_shortcuts: List[str] = []

    def start(self) -> None:
        if sys.platform != "win32" or self._running:
            return
        ready = threading.Event()
        self._running = True
        self._thread = threading.Thread(
            target=self._win32_loop, args=(ready,), daemon=True, name="JarvisHotkeys"
        )
        self._thread.start()
        ready.wait(timeout=2.0)

    def stop(self) -> None:
        if not self._running:
            return
        self._running = False
        if sys.platform == "win32" and self._thread_id is not None:
            try:
                ctypes.windll.user32.PostThreadMessageW(
                    self._thread_id, WM_QUIT, 0, 0
                )
            except Exception:
                pass

    def _win32_loop(self, ready: threading.Event) -> None:
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        self._thread_id = kernel32.GetCurrentThreadId()

        bindings = [
            (1, MOD_ALT | MOD_NOREPEAT, VK_J, "Alt+J", "ptt"),
            (2, MOD_NOREPEAT, VK_F9, "F9", "ptt"),
            (3, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, VK_S, "Ctrl+Alt+S", "vision"),
            (4, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, VK_H, "Ctrl+Alt+H", "hands_free"),
            (5, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, VK_X, "Ctrl+Alt+X", "interrupt"),
        ]

        id_to_action: Dict[int, str] = {}
        for hk_id, mods, vk, label, action in bindings:
            if user32.RegisterHotKey(None, hk_id, mods, vk):
                id_to_action[hk_id] = action
                self.registered_shortcuts.append(f"{label} ({action})")

        ready.set()

        msg = wintypes.MSG()
        try:
            while self._running:
                res = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if res <= 0 or msg.message == WM_QUIT:
                    break
                if msg.message == WM_HOTKEY:
                    action_name = id_to_action.get(int(msg.wParam))
                    if action_name and action_name in self._callbacks:
                        threading.Thread(
                            target=self._callbacks[action_name],
                            daemon=True,
                        ).start()
        finally:
            for hk_id in id_to_action:
                try:
                    user32.UnregisterHotKey(None, hk_id)
                except Exception:
                    pass
