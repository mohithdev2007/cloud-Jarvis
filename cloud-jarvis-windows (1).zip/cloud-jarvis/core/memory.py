"""Lightweight persistent memory, tasks, notes, and background timers for JARVIS."""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from core.config import DATA_DIR

MEMORY_FILE: Path = DATA_DIR / "memory.json"


class JarvisMemory:
    """Thread-safe JSON persistence (~0.1 MB RAM) with live countdown timers."""

    def __init__(self, on_timer_done: Optional[Callable[[str], None]] = None) -> None:
        self._lock = threading.RLock()
        self._on_timer_done = on_timer_done
        self._timers: Dict[int, Dict[str, Any]] = {}
        self._next_timer_id = 1
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._data = self._load()

    def set_timer_callback(self, callback: Callable[[str], None]) -> None:
        self._on_timer_done = callback

    def _load(self) -> Dict[str, Any]:
        default_state: Dict[str, Any] = {
            "facts": [],
            "todos": [],
            "notes": [],
        }
        if not MEMORY_FILE.exists():
            return default_state
        try:
            loaded = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                for k, v in default_state.items():
                    loaded.setdefault(k, v)
                return loaded
        except Exception:
            pass
        return default_state

    def _save(self) -> None:
        tmp_path = MEMORY_FILE.with_suffix(".tmp")
        tmp_path.write_text(
            json.dumps(self._data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp_path.replace(MEMORY_FILE)

    # ---- Long-term Facts ----
    def remember_fact(self, fact: str) -> str:
        clean = fact.strip()
        if not clean:
            return "Nothing provided to remember."
        with self._lock:
            existing = [f["text"].lower() for f in self._data["facts"]]
            if clean.lower() in existing:
                return f"Already stored in memory: '{clean}'."
            self._data["facts"].append(
                {
                    "text": clean,
                    "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                }
            )
            # Cap at 100 facts so prompt stays lean on tokens
            if len(self._data["facts"]) > 100:
                self._data["facts"] = self._data["facts"][-100:]
            self._save()
        return f"Saved to long-term memory: '{clean}'."

    def forget_fact(self, keyword: str) -> str:
        kw = keyword.strip().lower()
        if not kw:
            return "Please provide a keyword to forget."
        with self._lock:
            before = len(self._data["facts"])
            self._data["facts"] = [
                f for f in self._data["facts"] if kw not in f["text"].lower()
            ]
            removed = before - len(self._data["facts"])
            if removed:
                self._save()
                return f"Removed {removed} memory item(s) matching '{keyword}'."
            return f"No memory items matched '{keyword}'."

    def list_facts(self) -> List[str]:
        with self._lock:
            return [f["text"] for f in self._data["facts"]]

    def prompt_context_block(self) -> str:
        """Compact summary injected into system prompt."""
        with self._lock:
            facts = [f["text"] for f in self._data["facts"][-25:]]
            pending_todos = [
                f"[{t['id']}] {t['task']}"
                for t in self._data["todos"]
                if not t.get("done")
            ][:10]
        parts: List[str] = []
        if facts:
            parts.append("Known facts about the user:\n- " + "\n- ".join(facts))
        if pending_todos:
            parts.append("Pending to-do items:\n- " + "\n- ".join(pending_todos))
        return "\n\n".join(parts)

    # ---- To-Do Tasks ----
    def add_todo(self, task: str) -> str:
        clean = task.strip()
        if not clean:
            return "Task description cannot be empty."
        with self._lock:
            next_id = (
                max((int(t.get("id", 0)) for t in self._data["todos"]), default=0) + 1
            )
            self._data["todos"].append(
                {
                    "id": next_id,
                    "task": clean,
                    "done": False,
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                }
            )
            self._save()
        return f"Added task #{next_id}: {clean}"

    def complete_todo(self, task_id_or_query: str) -> str:
        q = str(task_id_or_query).strip().lower().lstrip("#")
        with self._lock:
            for item in self._data["todos"]:
                if str(item["id"]) == q or (
                    not item["done"] and q and q in item["task"].lower()
                ):
                    item["done"] = True
                    self._save()
                    return f"Marked task #{item['id']} complete: {item['task']}"
        return f"Could not find an open task matching '{task_id_or_query}'."

    def clear_completed_todos(self) -> str:
        with self._lock:
            before = len(self._data["todos"])
            self._data["todos"] = [t for t in self._data["todos"] if not t.get("done")]
            removed = before - len(self._data["todos"])
            self._save()
        return f"Cleared {removed} completed task(s)."

    def list_todos_formatted(self) -> str:
        with self._lock:
            todos = list(self._data["todos"])
        if not todos:
            return "Your to-do list is currently empty."
        lines = []
        for t in todos:
            mark = "[x]" if t.get("done") else "[ ]"
            lines.append(f"{mark} #{t['id']}: {t['task']}")
        return "\n".join(lines)

    # ---- Quick Notes ----
    def save_note(self, title: str, content: str) -> str:
        with self._lock:
            self._data["notes"].append(
                {
                    "title": title.strip() or "Quick Note",
                    "content": content.strip(),
                    "saved_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                }
            )
            if len(self._data["notes"]) > 100:
                self._data["notes"] = self._data["notes"][-100:]
            self._save()
        return f"Saved note '{title.strip() or 'Quick Note'}'."

    def get_notes_formatted(self, query: str = "") -> str:
        q = query.strip().lower()
        with self._lock:
            notes = list(self._data["notes"])
        if q:
            notes = [
                n
                for n in notes
                if q in n["title"].lower() or q in n["content"].lower()
            ]
        if not notes:
            return "No matching notes found." if q else "No saved notes yet."
        return "\n---\n".join(
            f"[{n['saved_at']}] {n['title']}: {n['content']}" for n in notes[-10:]
        )

    # ---- Background Timers ----
    def start_timer(self, seconds: int, label: str = "Timer") -> str:
        secs = max(1, min(86400, int(seconds)))
        clean_label = label.strip() or "Timer"

        with self._lock:
            tid = self._next_timer_id
            self._next_timer_id += 1
            due_ts = time.time() + secs

            def _fire() -> None:
                with self._lock:
                    self._timers.pop(tid, None)
                if self._on_timer_done:
                    self._on_timer_done(clean_label)

            timer_obj = threading.Timer(secs, _fire)
            timer_obj.daemon = True
            self._timers[tid] = {
                "id": tid,
                "label": clean_label,
                "due_ts": due_ts,
                "timer": timer_obj,
            }
            timer_obj.start()

        mins, rem = divmod(secs, 60)
        hrs, mins = divmod(mins, 60)
        parts = []
        if hrs:
            parts.append(f"{hrs}h")
        if mins:
            parts.append(f"{mins}m")
        if rem or not parts:
            parts.append(f"{rem}s")
        return f"Started timer #{tid} ('{clean_label}') for {' '.join(parts)}."

    def list_timers_formatted(self) -> str:
        now = time.time()
        with self._lock:
            if not self._timers:
                return "No active timers."
            lines = []
            for tid, info in self._timers.items():
                rem = max(0, int(info["due_ts"] - now))
                m, s = divmod(rem, 60)
                lines.append(f"Timer #{tid} ({info['label']}): {m}m {s}s remaining")
            return "\n".join(lines)

    def cancel_all_timers(self) -> str:
        with self._lock:
            count = len(self._timers)
            for info in self._timers.values():
                info["timer"].cancel()
            self._timers.clear()
        return f"Cancelled {count} active timer(s)."
