"""Free Cloud AI Provider Endpoints & Dynamic Model Auto-Discovery.

Supports 100% Free ($0 / No Credit Card) Cloud Providers out of the box:
1. Google Gemini Free Tier (https://aistudio.google.com/apikey -> AIza...)
2. Groq Free Developer Cloud (https://console.groq.com/keys -> gsk_...)
3. OpenRouter Free Models (https://openrouter.ai/keys -> sk-or-...)
4. Optional OpenAI (sk-...)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from openai import OpenAI

from core.config import detect_provider_from_key

PROVIDER_BASE_URLS: Dict[str, Optional[str]] = {
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai/",
    "groq": "https://api.groq.com/openai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "openai": None,
}

PROVIDER_LABELS: Dict[str, str] = {
    "gemini": "Google Gemini Free Cloud",
    "groq": "Groq Free LPU Cloud",
    "openrouter": "OpenRouter Free Cloud",
    "openai": "OpenAI Cloud",
}

PREFERRED_CHAT_MODELS: Dict[str, List[str]] = {
    "gemini": [
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-3-flash",
        "gemini-3.1-flash-lite",
        "gemini-2.0-flash",
    ],
    "groq": [
        "llama-3.3-70b-versatile",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "meta-llama/llama-4-maverick-17b-128e-instruct",
        "openai/gpt-oss-120b",
        "openai/gpt-oss-20b",
        "qwen/qwen3.8-27b",
        "qwen/qwen3-32b",
        "llama-3.1-8b-instant",
    ],
    "openrouter": [
        "google/gemini-2.5-flash:free",
        "meta-llama/llama-3.3-70b-instruct:free",
        "qwen/qwen3-32b:free",
        "openrouter/free",
    ],
    "openai": [
        "gpt-4.1-mini",
        "gpt-4o-mini",
    ],
}

PREFERRED_VISION_MODELS: Dict[str, List[str]] = {
    "gemini": [
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-3-flash",
        "gemini-2.0-flash",
    ],
    "groq": [
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "meta-llama/llama-4-maverick-17b-128e-instruct",
        "llama-3.2-90b-vision-preview",
        "llama-3.2-11b-vision-preview",
    ],
    "openrouter": [
        "google/gemini-2.5-flash:free",
        "meta-llama/llama-3.2-11b-vision-instruct:free",
        "openrouter/free",
    ],
    "openai": [
        "gpt-4.1-mini",
        "gpt-4o-mini",
    ],
}

_DISCOVERED_MODELS_CACHE: Dict[str, List[str]] = {}


def build_cloud_client(provider: str, api_key: str, timeout: float = 40.0) -> OpenAI:
    base_url = PROVIDER_BASE_URLS.get(provider)
    kwargs = {"api_key": api_key, "timeout": timeout}
    if base_url:
        kwargs["base_url"] = base_url
    return OpenAI(**kwargs)


def discover_account_models(provider: str, client: OpenAI) -> List[str]:
    """Fetch live model IDs available on this account and normalize names."""
    cache_key = f"{provider}:{id(client)}"
    if cache_key in _DISCOVERED_MODELS_CACHE:
        return _DISCOVERED_MODELS_CACHE[cache_key]

    found: List[str] = []
    try:
        listing = client.models.list()
        for item in listing.data:
            mid = getattr(item, "id", "") or ""
            if mid.startswith("models/"):
                mid = mid[len("models/") :]
            if mid:
                found.append(mid)
    except Exception:
        pass

    _DISCOVERED_MODELS_CACHE[cache_key] = found
    return found


def _is_chat_capable_id(provider: str, model_id: str) -> bool:
    low = model_id.lower()
    excluded_substrings = (
        "whisper",
        "tts",
        "embed",
        "guard",
        "moderation",
        "imagen",
        "veo",
        "aqa",
        "bison",
        "gecko",
        "native-audio",
        "transcribe",
        "dall-e",
        "orpheus",
        "playai",
    )
    if any(bad in low for bad in excluded_substrings):
        return False
    if provider == "gemini":
        return "gemini" in low and "flash" in low and "-image" not in low
    if provider == "openrouter":
        return low.endswith(":free") or low == "openrouter/free"
    return True


def resolve_chat_models(provider: str, client: OpenAI, user_override: str = "auto") -> List[str]:
    """Return ordered list of candidate chat/tool models for automatic fallback."""
    if user_override and user_override.lower() != "auto":
        return [user_override]

    live = discover_account_models(provider, client)
    prefs = PREFERRED_CHAT_MODELS.get(provider, [])

    if not live:
        return list(prefs)

    live_set = set(live)
    ranked = [m for m in prefs if m in live_set]

    # Append any newly released flash / free models discovered on the account!
    for m in live:
        if m not in ranked and _is_chat_capable_id(provider, m):
            ranked.append(m)

    return ranked or list(prefs)


def resolve_vision_models(provider: str, client: OpenAI, user_override: str = "auto") -> List[str]:
    """Return ordered list of candidate Vision models for screen inspection."""
    if user_override and user_override.lower() != "auto":
        return [user_override]

    live = discover_account_models(provider, client)
    prefs = PREFERRED_VISION_MODELS.get(provider, [])

    if not live:
        return list(prefs)

    live_set = set(live)
    ranked = [m for m in prefs if m in live_set]

    for m in live:
        low = m.lower()
        if m not in ranked and _is_chat_capable_id(provider, m):
            if provider == "gemini" or "vision" in low or "scout" in low or "maverick" in low:
                ranked.append(m)

    return ranked or list(prefs)


def verify_any_cloud_key(raw_key: str) -> Tuple[bool, str, str, str]:
    """
    Validate a pasted API key against its auto-detected provider.
    Returns: (is_ok, status_message, provider_slug, env_var_name)
    """
    cleaned = (raw_key or "").strip().strip('"').strip("'")
    if len(cleaned) < 16:
        return (
            False,
            "Please paste a valid Free Gemini (AIza...) or Free Groq (gsk_...) API key.",
            "",
            "",
        )

    provider, env_var = detect_provider_from_key(cleaned)
    label = PROVIDER_LABELS.get(provider, provider.title())

    try:
        client = build_cloud_client(provider, cleaned, timeout=10.0)
        models = resolve_chat_models(provider, client, "auto")
        live = discover_account_models(provider, client)
        if not live and provider != "openrouter":
            # Force an explicit models.list() call to ensure auth check ran
            client.models.list()
        top_model = models[0] if models else "auto"
        return (
            True,
            f"✔ Verified {label}! Active model: {top_model}",
            provider,
            env_var,
        )
    except Exception as exc:
        msg = str(exc)
        if "401" in msg or "403" in msg or "invalid" in msg.lower() or "api_key_invalid" in msg.lower():
            return False, f"Invalid {label} key. Double-check that you copied the full key.", provider, env_var
        return False, f"{label} connection error: {msg[:150]}", provider, env_var
