"""Central Event-Driven Controller connecting Free Cloud Audio, Brain, Memory, and Hotkeys."""

from __future__ import annotations

import re
import threading
import time
from typing import Callable, Optional

from core.audio_engine import CloudAudioEngine
from core.brain import JarvisBrain
from core.config import JarvisConfig
from core.hotkeys import GlobalHotkeyManager
from core.memory import JarvisMemory


class JarvisController:
    """Thread-safe coordinator driving both Floating HUD and Terminal CLI modes."""

    def __init__(
        self,
        config: JarvisConfig,
        *,
        on_state_change: Optional[Callable[[str, str], None]] = None,
        on_message: Optional[Callable[[str, str], None]] = None,
        on_audio_level: Optional[Callable[[float], None]] = None,
        on_hands_free_change: Optional[Callable[[bool], None]] = None,
    ) -> None:
        self.config = config
        self._on_state_change = on_state_change
        self._on_message = on_message
        self._on_hands_free_change = on_hands_free_change

        self.memory = JarvisMemory(on_timer_done=self._handle_timer_finished)
        self.audio = CloudAudioEngine(config=config, on_level=on_audio_level)
        self.brain = JarvisBrain(config=config, memory=self.memory)

        self.state: str = "idle"  # idle | listening | thinking | speaking
        self.status_detail: str = "Ready (Alt+J or F9 to speak)"
        self._busy_lock = threading.Lock()
        self._hands_free = config.hands_free_default
        self._running = True
        self._followup_until: float = 0.0
        self._hf_thread: Optional[threading.Thread] = None

        self.hotkeys = GlobalHotkeyManager(
            callbacks={
                "ptt": self.trigger_push_to_talk,
                "vision": self.trigger_screen_vision,
                "hands_free": self.toggle_hands_free,
                "interrupt": self.interrupt,
            }
        )

    @property
    def hands_free_enabled(self) -> bool:
        return self._hands_free

    def start_background_services(self) -> None:
        self.hotkeys.start()
        if self._hands_free:
            self._ensure_hands_free_thread()

    def shutdown(self) -> None:
        self._running = False
        self._hands_free = False
        self.audio.interrupt_speech()
        self.audio.finish_current_recording()
        self.hotkeys.stop()

    def _set_state(self, state: str, detail: str = "") -> None:
        self.state = state
        self.status_detail = detail
        if self._on_state_change:
            try:
                self._on_state_change(state, detail)
            except Exception:
                pass

    def _emit_message(self, role: str, text: str) -> None:
        if self._on_message and text:
            try:
                self._on_message(role, text)
            except Exception:
                pass

    def _handle_timer_finished(self, label: str) -> None:
        alert = f"Excuse me, {self.config.user_title}. Your timer for '{label}' is complete."
        self._emit_message("jarvis", f"⏰ {alert}")
        self.audio.play_chime("listen")
        if self.config.speak_responses:
            try:
                self._set_state("speaking", f"Timer complete: {label}")
                self.audio.speak_text(alert)
            except Exception:
                pass
            finally:
                self._set_state("idle", self._idle_hint())

    def _idle_hint(self) -> str:
        if self._hands_free:
            return f"Hands-Free ON — Say '{self.config.wake_word.title()}'"
        return "Ready — Press Alt+J or F9 ($0 Free Cloud)"

    def interrupt(self) -> None:
        """Stop JARVIS speech or cancel active mic capture."""
        if self.audio.is_speaking:
            self.audio.interrupt_speech()
            self._set_state("idle", "Speech interrupted")
        elif self.audio.is_recording:
            self.audio.finish_current_recording()

    def toggle_hands_free(self) -> bool:
        self._hands_free = not self._hands_free
        if self._on_hands_free_change:
            try:
                self._on_hands_free_change(self._hands_free)
            except Exception:
                pass
        if self._hands_free:
            self._ensure_hands_free_thread()
            self._set_state("idle", self._idle_hint())
        else:
            self._followup_until = 0.0
            self._set_state("idle", self._idle_hint())
        return self._hands_free

    def _ensure_hands_free_thread(self) -> None:
        if self._hf_thread and self._hf_thread.is_alive():
            return
        self._hf_thread = threading.Thread(
            target=self._hands_free_loop, daemon=True, name="JarvisHandsFree"
        )
        self._hf_thread.start()

    def submit_text_async(self, text: str, attach_screen: bool = False) -> None:
        threading.Thread(
            target=self._run_text_turn,
            args=(text, attach_screen),
            daemon=True,
        ).start()

    def _run_text_turn(self, text: str, attach_screen: bool = False) -> None:
        if not self.config.has_valid_key:
            self._emit_message(
                "system",
                "Click ⚙ Settings to paste a 100% FREE Google Gemini (AIza...) or Groq (gsk_...) key — takes 15 seconds, no credit card!",
            )
            return

        self.audio.interrupt_speech()
        if not self._busy_lock.acquire(blocking=False):
            return

        try:
            display_user = text.strip()
            if attach_screen:
                display_user = (
                    f"👁 [Screen Vision] {display_user}"
                    if display_user
                    else "👁 [Inspecting current Windows screen...]"
                )
            if display_user:
                self._emit_message("user", display_user)

            self._set_state("thinking", "Analyzing in Free Cloud...")

            def _on_tool(tool_name: str) -> None:
                pretty = tool_name.replace("_", " ").title()
                self._set_state("thinking", f"Running: {pretty}...")

            reply = self.brain.ask(
                text, attach_screen=attach_screen, on_tool_activity=_on_tool
            )
            if reply:
                self._emit_message("jarvis", reply)
                if self.config.speak_responses:
                    self._set_state("speaking", "JARVIS speaking (Ctrl+Alt+X to skip)")
                    self.audio.speak_text(reply)
        except Exception as exc:
            self._emit_message("system", f"Error: {exc}")
        finally:
            self._busy_lock.release()
            self._set_state("idle", self._idle_hint())

    def trigger_screen_vision(self) -> None:
        self.submit_text_async(
            "Examine my current screen. Explain any visible errors, important info, or what I'm looking at concisely.",
            attach_screen=True,
        )

    def trigger_push_to_talk(self) -> None:
        if self.audio.is_recording and self.state == "listening":
            self.audio.finish_current_recording()
            return
        if self.audio.is_speaking:
            self.audio.interrupt_speech()

        threading.Thread(target=self._ptt_worker, daemon=True).start()

    def _ptt_worker(self) -> None:
        if not self.config.has_valid_key:
            self._emit_message(
                "system",
                "Free API key missing — click ⚙ Settings to grab a 100% Free Gemini or Groq key (no card needed)!",
            )
            return
        if not self._busy_lock.acquire(blocking=False):
            return

        try:
            self._set_state("listening", "Listening... speak now (tap again to finish)")
            wav_bytes = self.audio.record_utterance(
                max_wait_for_speech_sec=6.0,
                silence_stop_sec=1.15,
                max_duration_sec=25.0,
                play_feedback=True,
            )
            if not wav_bytes:
                self._set_state("idle", "No speech detected")
                return

            self._set_state("thinking", "Transcribing voice ($0 Free STT)...")
            transcript = self.audio.transcribe_wav(wav_bytes)
            if not transcript:
                self._set_state("idle", "Didn't catch that")
                return

            self._emit_message("user", f"🎙 {transcript}")

            wants_screen = bool(
                re.search(
                    r"\b(on my screen|look at my screen|what is this error|read my screen|see my screen|this window)\b",
                    transcript.lower(),
                )
            )
            self._set_state(
                "thinking",
                "Inspecting screen..." if wants_screen else "Thinking...",
            )

            def _on_tool(tool_name: str) -> None:
                self._set_state("thinking", f"Running: {tool_name.replace('_', ' ')}...")

            reply = self.brain.ask(
                transcript,
                attach_screen=wants_screen,
                on_tool_activity=_on_tool,
            )
            if reply:
                self._emit_message("jarvis", reply)
                if self.config.speak_responses:
                    self._set_state("speaking", "Speaking...")
                    self.audio.speak_text(reply)
        except Exception as exc:
            self._emit_message("system", f"Voice error: {exc}")
        finally:
            self._busy_lock.release()
            self._set_state("idle", self._idle_hint())

    def _hands_free_loop(self) -> None:
        """Low-CPU local VAD wake-word listener; calls Free Cloud STT only when speech occurs."""
        while self._running and self._hands_free:
            if not self.config.has_valid_key or self.audio.is_speaking:
                time.sleep(0.25)
                continue

            if not self._busy_lock.acquire(blocking=False):
                time.sleep(0.2)
                continue

            try:
                in_followup = time.time() < self._followup_until
                if in_followup:
                    self._set_state("listening", "Listening for follow-up...")

                wav_bytes = self.audio.record_utterance(
                    max_wait_for_speech_sec=2.5,
                    silence_stop_sec=1.0,
                    max_duration_sec=18.0,
                    play_feedback=False,
                )
                if not wav_bytes or not self._hands_free:
                    continue

                transcript = self.audio.transcribe_wav(wav_bytes).strip()
                if not transcript:
                    continue

                wake = self.config.wake_word.lower()
                low = transcript.lower()
                has_wake = wake in low

                if not has_wake and not (time.time() < self._followup_until):
                    continue

                cleaned_cmd = transcript
                if has_wake:
                    pattern = rf"^[\s,.\-!]*(?:hey|hi|ok|okay|yo)?[\s,.\-!]*{re.escape(wake)}[\s,.\-!:?]*"
                    cleaned_cmd = re.sub(pattern, "", transcript, flags=re.IGNORECASE).strip()

                if not cleaned_cmd:
                    ack = f"At your service, {self.config.user_title}."
                    self._emit_message("jarvis", ack)
                    self._set_state("speaking", "Listening shortly...")
                    self.audio.speak_text(ack)
                    self._followup_until = time.time() + 9.0
                    continue

                self.audio.play_chime("done")
                self._emit_message("user", f"🎙 {cleaned_cmd}")

                wants_screen = bool(
                    re.search(
                        r"\b(on my screen|look at my screen|what is this error|read my screen|see my screen)\b",
                        cleaned_cmd.lower(),
                    )
                )
                self._set_state("thinking", "Thinking...")
                reply = self.brain.ask(cleaned_cmd, attach_screen=wants_screen)
                if reply:
                    self._emit_message("jarvis", reply)
                    if self.config.speak_responses:
                        self._set_state("speaking", "Speaking...")
                        self.audio.speak_text(reply)
                    self._followup_until = time.time() + 8.0
            except Exception:
                time.sleep(1.0)
            finally:
                self._busy_lock.release()
                if self._hands_free:
                    self._set_state("idle", self._idle_hint())
