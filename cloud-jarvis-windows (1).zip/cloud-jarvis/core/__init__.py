"""Core modules for Cloud JARVIS (Potato-PC Edition)."""
