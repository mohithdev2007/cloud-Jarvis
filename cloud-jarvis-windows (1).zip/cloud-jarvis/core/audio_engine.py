"""100% FREE Zero-Bloat Cloud Audio Engine (Free Cloud STT + Free Edge-TTS Neural Voice).

Engineered for Potato Windows PCs:
- Speech-to-Text ($0):
    1. Groq Free Cloud `whisper-large-v3-turbo` (if Groq free key is set — 0.2s latency!)
    2. Zero-Key Google Web Speech Recognition (`SpeechRecognition` — $0, no API key needed!)
    3. Google Gemini Free Multimodal Audio fallback (if Gemini free key is set)
- Text-to-Speech ($0, ZERO API Key):
    1. Microsoft Neural `edge-tts` (`en-GB-RyanNeural` British J.A.R.V.I.S. voice) decoded in-memory
       via `miniaudio` -> 24kHz PCM chunks with live HUD waveform + instant barge-in interrupt!
    2. Windows Native `winsound` / SAPI5 offline voice fallback.
"""

from __future__ import annotations

import array
import asyncio
import base64
import collections
import io
import json
import math
import re
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import wave
from typing import Callable, Optional

from core.config import JarvisConfig
from core.providers import build_cloud_client

SAMPLE_RATE_IN = 16000
BLOCK_SAMPLES_IN = 1600  # 100ms per block at 16kHz
SAMPLE_RATE_OUT_PCM = 24000

FREE_NEURAL_VOICES = [
    "en-GB-RyanNeural",         # Crisp British J.A.R.V.I.S. (Default)
    "en-GB-ThomasNeural",       # Classic British Gentleman
    "en-GB-SoniaNeural",        # British F.R.I.D.A.Y. Female
    "en-IN-PrabhatNeural",      # Clear Indian English Male
    "en-IN-NeerjaNeural",       # Clear Indian English Female
    "en-US-ChristopherNeural",  # Warm American Male
    "en-US-AriaNeural",         # Crisp American Female
]

_HALLUCINATION_PHRASES = {
    "you",
    "thank you",
    "thank you.",
    "thanks for watching.",
    "thanks for watching!",
    "bye.",
    "subtitles by the amara.org community",
    "...",
}


def pcm16_rms(raw_bytes: bytes) -> float:
    """Compute RMS amplitude of 16-bit little-endian mono PCM without numpy or audioop."""
    if not raw_bytes or len(raw_bytes) < 2:
        return 0.0
    if len(raw_bytes) % 2 == 1:
        raw_bytes = raw_bytes[:-1]
    samples = array.array("h")
    samples.frombytes(raw_bytes)
    if sys.byteorder != "little":
        samples.byteswap()
    n = len(samples)
    if n == 0:
        return 0.0
    total_sq = 0
    for s in samples:
        total_sq += s * s
    return math.sqrt(total_sq / n)


def pcm16_to_wav_bytes(pcm_bytes: bytes, sample_rate: int = SAMPLE_RATE_IN) -> bytes:
    """Wrap raw 16-bit mono PCM bytes into an in-memory RIFF WAV file."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_bytes)
    return buf.getvalue()


def synthesize_tone_pcm(
    freqs_hz: list[tuple[float, float]],
    sample_rate: int = 24000,
    volume: float = 0.16,
) -> bytes:
    """Generate a tiny sci-fi activation chime in pure stdlib (<8KB, 0 external assets)."""
    out = bytearray()
    for freq, dur_sec in freqs_hz:
        total_samples = int(sample_rate * dur_sec)
        fade = max(1, min(int(sample_rate * 0.012), total_samples // 3))
        for i in range(total_samples):
            env = 1.0
            if i < fade:
                env = i / fade
            elif i > total_samples - fade:
                env = (total_samples - i) / fade
            val = math.sin(2.0 * math.pi * freq * (i / sample_rate)) * volume * env
            sample_int = max(-32767, min(32767, int(val * 32767)))
            out.extend(struct.pack("<h", sample_int))
    return bytes(out)


def clean_text_for_speech(text: str) -> str:
    """Strip markdown formatting, code blocks, and raw URLs so spoken output sounds natural."""
    if not text:
        return ""
    cleaned = re.sub(
        r"```[\s\S]*?```",
        " I have placed the code snippet in the chat window. ",
        text,
    )
    cleaned = re.sub(r"`([^`]+)`", r"\1", cleaned)
    cleaned = re.sub(r"https?://\S+", "the link", cleaned)
    cleaned = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", cleaned)
    cleaned = re.sub(r"[*_#~>|]+", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if len(cleaned) > 950:
        cleaned = cleaned[:950].rsplit(" ", 1)[0] + "... Full details are on screen."
    return cleaned


class CloudAudioEngine:
    """100% Free Cloud Speech-to-Text + Free Edge-TTS Neural British Voice Engine."""

    def __init__(
        self,
        config: JarvisConfig,
        on_level: Optional[Callable[[float], None]] = None,
    ) -> None:
        self.config = config
        self.on_level = on_level
        self._interrupt_tts = threading.Event()
        self._stop_recording = threading.Event()
        self._is_speaking = False
        self._is_recording = False
        self._speak_lock = threading.Lock()
        self._ambient_rms: float = 160.0

        self._chime_listen = synthesize_tone_pcm([(587.33, 0.055), (880.0, 0.075)])
        self._chime_done = synthesize_tone_pcm([(880.0, 0.05), (659.25, 0.065)])

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    @property
    def is_recording(self) -> bool:
        return self._is_recording

    def interrupt_speech(self) -> None:
        """Immediately halt ongoing TTS playback (barge-in)."""
        self._interrupt_tts.set()
        if sys.platform == "win32":
            try:
                import winsound

                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass

    def finish_current_recording(self) -> None:
        """Stop current push-to-talk capture and process what was spoken so far."""
        self._stop_recording.set()

    def play_chime(self, kind: str = "listen") -> None:
        pcm = self._chime_listen if kind == "listen" else self._chime_done

        def _play() -> None:
            try:
                import sounddevice as sd

                with sd.RawOutputStream(
                    samplerate=SAMPLE_RATE_OUT_PCM, channels=1, dtype="int16"
                ) as stream:
                    stream.write(pcm)
                return
            except Exception:
                pass
            if sys.platform == "win32":
                try:
                    import winsound

                    wav = pcm16_to_wav_bytes(pcm, SAMPLE_RATE_OUT_PCM)
                    winsound.PlaySound(wav, winsound.SND_MEMORY)
                except Exception:
                    pass

        threading.Thread(target=_play, daemon=True).start()

    def record_utterance(
        self,
        max_wait_for_speech_sec: float = 5.5,
        silence_stop_sec: float = 1.15,
        max_duration_sec: float = 24.0,
        play_feedback: bool = True,
    ) -> Optional[bytes]:
        """Record a single spoken phrase using lightweight energy VAD; returns WAV bytes or None."""
        try:
            import sounddevice as sd
        except Exception as exc:
            raise RuntimeError(
                f"Microphone library (sounddevice) unavailable: {exc}"
            ) from exc

        self.interrupt_speech()
        self._stop_recording.clear()
        self._is_recording = True

        if play_feedback:
            self.play_chime("listen")
            time.sleep(0.12)

        pre_roll: collections.deque[bytes] = collections.deque(maxlen=4)
        captured_chunks: list[bytes] = []
        speech_started = False
        silence_blocks = 0
        speech_blocks = 0
        max_silence_blocks = max(4, int(silence_stop_sec * 10))
        max_wait_blocks = max(8, int(max_wait_for_speech_sec * 10))
        max_total_blocks = max(30, int(max_duration_sec * 10))
        ambient_samples: list[float] = []

        try:
            with sd.RawInputStream(
                samplerate=SAMPLE_RATE_IN,
                blocksize=BLOCK_SAMPLES_IN,
                channels=1,
                dtype="int16",
            ) as stream:
                for block_idx in range(max_total_blocks):
                    if self._stop_recording.is_set():
                        break
                    raw_buf, _overflowed = stream.read(BLOCK_SAMPLES_IN)
                    chunk = bytes(raw_buf)
                    rms = pcm16_rms(chunk)

                    if self.on_level:
                        self.on_level(min(1.0, rms / 2800.0))

                    if not speech_started and len(ambient_samples) < 3 and rms < 900:
                        ambient_samples.append(rms)
                        self._ambient_rms = max(
                            90.0,
                            min(650.0, sum(ambient_samples) / len(ambient_samples)),
                        )

                    threshold = max(275.0, self._ambient_rms * 2.35)

                    if not speech_started:
                        pre_roll.append(chunk)
                        if rms >= threshold:
                            speech_started = True
                            speech_blocks = 1
                            captured_chunks.extend(pre_roll)
                        elif block_idx >= max_wait_blocks:
                            return None
                    else:
                        captured_chunks.append(chunk)
                        if rms >= threshold * 0.78:
                            speech_blocks += 1
                            silence_blocks = 0
                        else:
                            silence_blocks += 1
                            if silence_blocks >= max_silence_blocks:
                                break
        finally:
            self._is_recording = False
            if self.on_level:
                self.on_level(0.0)

        if not captured_chunks or speech_blocks < 2:
            return None

        if play_feedback:
            self.play_chime("done")

        return pcm16_to_wav_bytes(b"".join(captured_chunks), SAMPLE_RATE_IN)

    # ========================================================================
    # 100% FREE SPEECH-TO-TEXT CHAIN
    # ========================================================================
    def transcribe_wav(self, wav_bytes: bytes) -> str:
        """Transcribe WAV audio using Free Groq Whisper -> Zero-Key Google Speech -> Free Gemini Audio."""
        if not wav_bytes:
            return ""

        # 1. Groq Free Whisper (0.2s speed when Groq free key is configured)
        if len(self.config.groq_api_key) >= 16:
            try:
                txt = self._transcribe_via_groq_whisper(wav_bytes)
                if txt:
                    return txt
            except Exception:
                pass

        # 2. Zero-API-Key Free Google Web Speech Recognition ($0, works out of the box!)
        try:
            txt = self._transcribe_via_free_google_web(wav_bytes)
            if txt:
                return txt
        except Exception:
            pass

        # 3. Google Gemini Free Multimodal Audio endpoint (backup if SpeechRecognition fails)
        if len(self.config.gemini_api_key) >= 16:
            try:
                txt = self._transcribe_via_gemini_audio(wav_bytes)
                if txt:
                    return txt
            except Exception:
                pass

        # 4. Optional OpenAI Whisper fallback if user only configured an OpenAI key
        if len(self.config.openai_api_key) >= 16:
            try:
                client = build_cloud_client("openai", self.config.openai_api_key, timeout=20.0)
                resp = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=("speech.wav", io.BytesIO(wav_bytes), "audio/wav"),
                )
                txt = (getattr(resp, "text", "") or "").strip()
                if txt.lower() not in _HALLUCINATION_PHRASES:
                    return txt
            except Exception:
                pass

        return ""

    def _transcribe_via_groq_whisper(self, wav_bytes: bytes) -> str:
        client = build_cloud_client("groq", self.config.groq_api_key, timeout=18.0)
        for model_name in ("whisper-large-v3-turbo", "whisper-large-v3"):
            try:
                kwargs = {
                    "model": model_name,
                    "file": ("speech.wav", io.BytesIO(wav_bytes), "audio/wav"),
                }
                if self.config.language:
                    kwargs["language"] = self.config.language
                resp = client.audio.transcriptions.create(**kwargs)
                text = (getattr(resp, "text", "") or "").strip()
                if text.lower() in _HALLUCINATION_PHRASES:
                    return ""
                return text
            except Exception:
                continue
        return ""

    def _transcribe_via_free_google_web(self, wav_bytes: bytes) -> str:
        import speech_recognition as sr

        recognizer = sr.Recognizer()
        with sr.AudioFile(io.BytesIO(wav_bytes)) as source:
            audio_data = recognizer.record(source)

        lang_map = {
            "en": "en-IN",  # Great recognition for both Indian & global English accents
            "hi": "hi-IN",
            "te": "te-IN",
        }
        lang_tag = lang_map.get((self.config.language or "en").lower(), self.config.language or "en-US")
        try:
            text = recognizer.recognize_google(audio_data, language=lang_tag)
        except sr.UnknownValueError:
            return ""
        text = (text or "").strip()
        if text.lower() in _HALLUCINATION_PHRASES:
            return ""
        return text

    def _transcribe_via_gemini_audio(self, wav_bytes: bytes) -> str:
        b64_wav = base64.b64encode(wav_bytes).decode("ascii")
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"gemini-2.5-flash:generateContent?key={self.config.gemini_api_key}"
        )
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": (
                                "Transcribe the spoken words in this audio accurately. "
                                "Return ONLY the raw spoken words with no quotes or commentary. "
                                "If silent, return an empty string."
                            )
                        },
                        {
                            "inlineData": {
                                "mimeType": "audio/wav",
                                "data": b64_wav,
                            }
                        },
                    ]
                }
            ]
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15.0) as resp:
            body = json.loads(resp.read().decode("utf-8", errors="replace"))
        candidates = body.get("candidates") or []
        if not candidates:
            return ""
        parts = candidates[0].get("content", {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts).strip()
        if text.lower() in _HALLUCINATION_PHRASES:
            return ""
        return text

    # ========================================================================
    # 100% FREE NEURAL BRITISH J.A.R.V.I.S. VOICE (EDGE-TTS + MINIAUDIO)
    # ========================================================================
    def speak_text(self, text: str) -> None:
        """Speak text for $0 using Microsoft Edge Neural TTS (`en-GB-RyanNeural`) + SAPI5 fallback."""
        if not self.config.speak_responses:
            return
        spoken = clean_text_for_speech(text)
        if not spoken:
            return

        with self._speak_lock:
            self._interrupt_tts.clear()
            self._is_speaking = True
            try:
                pcm_bytes = self._synthesize_edge_tts_pcm(spoken)
                if pcm_bytes and not self._interrupt_tts.is_set():
                    self._play_pcm_with_interrupt(pcm_bytes)
            except Exception:
                # Offline Windows SAPI5 fallback so JARVIS never goes mute even offline!
                self._fallback_windows_sapi(spoken)
            finally:
                self._is_speaking = False
                if self.on_level:
                    self.on_level(0.0)

    def _synthesize_edge_tts_pcm(self, spoken: str) -> bytes:
        import edge_tts
        import miniaudio

        voice = self.config.tts_voice or "en-GB-RyanNeural"
        if "Neural" not in voice:
            voice = "en-GB-RyanNeural"

        async def _fetch_mp3() -> bytes:
            comm = edge_tts.Communicate(spoken, voice=voice, rate="+4%")
            mp3_buf = bytearray()
            async for chunk in comm.stream():
                if self._interrupt_tts.is_set():
                    return b""
                if chunk.get("type") == "audio" and chunk.get("data"):
                    mp3_buf.extend(chunk["data"])
            return bytes(mp3_buf)

        mp3_bytes = asyncio.run(_fetch_mp3())
        if not mp3_bytes or self._interrupt_tts.is_set():
            return b""

        decoded = miniaudio.decode(
            mp3_bytes,
            output_format=miniaudio.SampleFormat.SIGNED16,
            nchannels=1,
            sample_rate=SAMPLE_RATE_OUT_PCM,
        )
        return decoded.samples.tobytes()

    def _play_pcm_with_interrupt(self, pcm_bytes: bytes) -> None:
        try:
            import sounddevice as sd

            chunk_bytes = 4800  # 100ms per slice at 24kHz 16-bit mono
            with sd.RawOutputStream(
                samplerate=SAMPLE_RATE_OUT_PCM,
                channels=1,
                dtype="int16",
            ) as out_stream:
                for offset in range(0, len(pcm_bytes), chunk_bytes):
                    if self._interrupt_tts.is_set():
                        break
                    piece = pcm_bytes[offset : offset + chunk_bytes]
                    if self.on_level:
                        self.on_level(min(1.0, pcm16_rms(piece) / 3600.0))
                    out_stream.write(piece)
            return
        except Exception:
            pass

        # Fallback to Windows native winsound WAV memory player
        if sys.platform == "win32" and not self._interrupt_tts.is_set():
            import winsound

            wav_bytes = pcm16_to_wav_bytes(pcm_bytes, SAMPLE_RATE_OUT_PCM)
            winsound.PlaySound(wav_bytes, winsound.SND_MEMORY)

    def _fallback_windows_sapi(self, spoken: str) -> None:
        if sys.platform != "win32" or self._interrupt_tts.is_set():
            return
        safe_txt = spoken.replace("'", "''")[:500]
        ps_cmd = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$s.Rate = 1; "
            f"$s.Speak('{safe_txt}')"
        )
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                timeout=25,
                creationflags=flags,
            )
        except Exception:
            pass
