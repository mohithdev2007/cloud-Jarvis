"""100% Free Cloud JARVIS Brain — Multi-Provider Tool-Calling Agent (Gemini Free + Groq Free)."""

from __future__ import annotations

import threading
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

from openai import OpenAI

from core.config import JarvisConfig
from core.memory import JarvisMemory
from core.providers import (
    build_cloud_client,
    resolve_chat_models,
    resolve_vision_models,
    verify_any_cloud_key,
)
from tools import vision
from tools.registry import OPENAI_TOOLS_SCHEMA, execute_tool_call


def verify_api_key(api_key: str) -> Tuple[bool, str, str, str]:
    """Validate any pasted Free Cloud key (Gemini AIza..., Groq gsk_..., OpenRouter sk-or-...)."""
    return verify_any_cloud_key(api_key)


class JarvisBrain:
    """Stateless-CPU Free Cloud reasoning engine with automatic provider/model failover."""

    def __init__(self, config: JarvisConfig, memory: JarvisMemory) -> None:
        self.config = config
        self.memory = memory
        self._lock = threading.Lock()
        self._clients: Dict[Tuple[str, str], OpenAI] = {}
        self.history: List[Dict[str, Any]] = []

    def _get_client(self, provider: str, api_key: str) -> OpenAI:
        cache_key = (provider, api_key)
        if cache_key not in self._clients:
            self._clients[cache_key] = build_cloud_client(provider, api_key, timeout=40.0)
        return self._clients[cache_key]

    def clear_conversation(self) -> None:
        with self._lock:
            self.history.clear()

    def _build_system_prompt(self) -> str:
        now_str = datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")
        title = self.config.user_title or "sir"
        mem_block = self.memory.prompt_context_block()

        prompt = (
            "You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), running as a 100% FREE, "
            "ultra-lightweight Cloud AI Desktop Assistant on the user's Windows PC ('Potato-PC Edition' — "
            "0% local GPU, tiny RAM footprint).\n"
            f"Current local date & time: {now_str}.\n"
            f"Address the user respectfully and naturally (e.g., '{title}' occasionally, without overdoing it).\n\n"
            "CORE BEHAVIOR:\n"
            "1. Keep responses crisp, natural, and voice-friendly (1 to 3 sentences for spoken actions/questions) "
            "unless the user asks for code, deep explanations, or lists.\n"
            "2. You have real tools to control this Windows PC: launch Start Menu apps, open websites/YouTube, "
            "control volume/media/brightness, read/write clipboard, inspect the live screen with Cloud Vision, "
            "check PC health, boost/free Potato-PC RAM, search/open local files, search the live web, check weather, "
            "and manage persistent memory, todos, notes, and voice timers. Use tools proactively!\n"
            "3. When the user tells you personal details or preferences (their name, specs, city, projects), "
            "save them with `manage_memory` so you remember across restarts.\n"
            "4. Never claim you performed a PC action unless you actually invoked the tool."
        )
        if mem_block:
            prompt += f"\n\nPERSISTENT MEMORY CONTEXT:\n{mem_block}"
        return prompt

    def _trim_history_safely(self) -> None:
        """Trim older messages ONLY at 'user' message boundaries so tool_call pairs never orphan."""
        max_len = max(6, self.config.max_history)
        if len(self.history) <= max_len:
            return
        start_idx = len(self.history) - max_len
        while start_idx < len(self.history) and self.history[start_idx].get("role") != "user":
            start_idx += 1
        self.history = self.history[start_idx:]

    def ask(
        self,
        user_text: str,
        *,
        attach_screen: bool = False,
        on_tool_activity: Optional[Callable[[str], None]] = None,
    ) -> str:
        """Process a user voice/text turn across Free Cloud AI, run PC tools, and return reply."""
        clean_input = (user_text or "").strip()
        if not clean_input and not attach_screen:
            return ""

        if not self.config.has_valid_key:
            raise RuntimeError(
                "No Free Cloud API key configured yet. Click ⚙ Settings to get a 100% Free Gemini or Groq key in 15 seconds (no credit card!)."
            )

        with self._lock:
            has_inline_image = False
            if attach_screen:
                prompt_text = (
                    clean_input
                    or "Inspect my current Windows screen, summarize what is open, and point out anything helpful."
                )
                try:
                    b64_img = vision.capture_screen_jpeg_b64()
                    user_msg: Dict[str, Any] = {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt_text},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{b64_img}",
                                },
                            },
                        ],
                    }
                    has_inline_image = True
                except Exception as exc:
                    user_msg = {
                        "role": "user",
                        "content": f"{prompt_text}\n[Note: Screen capture failed: {exc}]",
                    }
            else:
                user_msg = {"role": "user", "content": clean_input}

            self.history.append(user_msg)
            self._trim_history_safely()

            for _step in range(6):
                messages = [{"role": "system", "content": self._build_system_prompt()}] + self.history
                resp_msg = self._call_cloud_with_failover(
                    messages, require_vision=has_inline_image
                )

                tool_calls = getattr(resp_msg, "tool_calls", None)
                if not tool_calls:
                    reply_text = (resp_msg.content or "").strip()
                    self._compact_vision_payloads()
                    self.history.append({"role": "assistant", "content": reply_text})
                    return reply_text

                assistant_entry: Dict[str, Any] = {
                    "role": "assistant",
                    "content": resp_msg.content or "",
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments or "{}",
                            },
                        }
                        for tc in tool_calls
                    ],
                }
                self.history.append(assistant_entry)
                # Once screenshot was read on step 0, compact before follow-up tool rounds
                if has_inline_image:
                    self._compact_vision_payloads()
                    has_inline_image = False

                for tc in tool_calls:
                    fn_name = tc.function.name
                    fn_args = tc.function.arguments or "{}"
                    result_str = execute_tool_call(
                        fn_name,
                        fn_args,
                        config=self.config,
                        memory=self.memory,
                        on_tool_activity=on_tool_activity,
                    )
                    self.history.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": str(result_str)[:4500],
                        }
                    )

            self._compact_vision_payloads()
            fallback_done = f"I've completed the requested operations, {self.config.user_title}."
            self.history.append({"role": "assistant", "content": fallback_done})
            return fallback_done

    def _compact_vision_payloads(self) -> None:
        """Replace base64 image blobs in older turns with text markers to save RAM & free-tier quota."""
        for msg in self.history:
            content = msg.get("content")
            if isinstance(content, list):
                texts = [
                    part.get("text", "")
                    for part in content
                    if isinstance(part, dict) and part.get("type") == "text"
                ]
                msg["content"] = " ".join(texts).strip() + " [Attached screenshot inspected]"

    def _call_cloud_with_failover(
        self, messages: List[Dict[str, Any]], require_vision: bool = False
    ) -> Any:
        providers = self.config.active_providers_ordered()
        if require_vision:
            # Prefer Gemini first when inline screenshot is attached
            providers = sorted(
                providers, key=lambda item: 0 if item[0] == "gemini" else 1
            )

        last_err: Optional[Exception] = None
        for provider_name, api_key in providers:
            client = self._get_client(provider_name, api_key)
            models = (
                resolve_vision_models(provider_name, client, self.config.vision_model)
                if require_vision
                else resolve_chat_models(provider_name, client, self.config.chat_model)
            )

            for model_name in models[:4]:
                try:
                    req_kwargs: Dict[str, Any] = {
                        "model": model_name,
                        "messages": messages,
                    }
                    # When inline base64 screenshot is sent to some vision models, omit tools if model rejects combo,
                    # otherwise include full 20-tool schema:
                    req_kwargs["tools"] = OPENAI_TOOLS_SCHEMA
                    req_kwargs["tool_choice"] = "auto"

                    resp = client.chat.completions.create(**req_kwargs)
                    return resp.choices[0].message
                except Exception as exc:
                    err_str = str(exc).lower()
                    last_err = exc
                    # If a vision model doesn't support simultaneous tool declarations on inline image, retry without tools
                    if require_vision and ("tool" in err_str or "function" in err_str or "400" in err_str):
                        try:
                            resp = client.chat.completions.create(
                                model=model_name,
                                messages=messages,
                            )
                            return resp.choices[0].message
                        except Exception as inner_exc:
                            last_err = inner_exc
                    # If Groq Llama had transient tool_use_failed formatting hiccup, retry without tools or hop to next model
                    if "tool_use_failed" in err_str:
                        continue
                    continue

        raise RuntimeError(f"Cloud AI request failed: {last_err}") from last_err
