#!/usr/bin/env python3
"""Cloud J.A.R.V.I.S. — Potato-PC Windows Edition (Main Entrypoint).

Usage:
  python jarvis.py          # Launch Floating Arc-Reactor HUD (default)
  python jarvis.py --cli    # Launch Ultra-Lean ~20MB RAM Terminal Mode
"""

from __future__ import annotations

import argparse
import ctypes
import sys

from core.config import JarvisConfig


def _configure_windows_dpi() -> None:
    """Enable crisp Per-Monitor DPI scaling on Windows 10/11 laptops."""
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


_MUTEX_HANDLE = None


def _acquire_single_instance_lock() -> bool:
    """Prevent accidental duplicate background instances fighting over hotkeys & mic."""
    global _MUTEX_HANDLE
    if sys.platform != "win32":
        return True
    try:
        kernel32 = ctypes.windll.kernel32
        _MUTEX_HANDLE = kernel32.CreateMutexW(
            None, False, "Local\\CloudJarvisPotatoEditionMutex"
        )
        ERROR_ALREADY_EXISTS = 183
        if kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
            return False
    except Exception:
        pass
    return True


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Cloud J.A.R.V.I.S. — Ultra-lightweight OpenAI Desktop Assistant for Windows"
    )
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Run in ultra-minimal terminal mode (~20MB RAM, no GUI)",
    )
    parser.add_argument(
        "--hands-free",
        action="store_true",
        help="Start with Hands-Free wake-word listening enabled immediately",
    )
    parser.add_argument(
        "--allow-multiple",
        action="store_true",
        help="Bypass single-instance check",
    )
    args = parser.parse_args()

    if not args.allow_multiple and not _acquire_single_instance_lock():
        if sys.platform == "win32":
            ctypes.windll.user32.MessageBoxW(
                0,
                "Cloud J.A.R.V.I.S. is already running!\n\nPress Alt+J or F9 to speak to it.",
                "J.A.R.V.I.S. Cloud",
                0x40,
            )
        else:
            print("Cloud JARVIS is already running.")
        return 0

    config = JarvisConfig.load()
    if args.hands_free:
        config.hands_free_default = True

    if args.cli:
        from ui.cli import run_cli_mode

        run_cli_mode(config)
        return 0

    _configure_windows_dpi()
    try:
        from ui.hud import JarvisFloatingHUD

        hud = JarvisFloatingHUD(config)
        hud.run()
    except Exception as exc:
        print(f"[Notice] GUI unavailable ({exc}); falling back to Terminal CLI mode.")
        from ui.cli import run_cli_mode

        run_cli_mode(config)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
