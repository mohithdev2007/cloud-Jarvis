"""Automated test suite for 100% Free Cloud JARVIS (Potato-PC Windows Edition)."""

from __future__ import annotations

import io
import json
import struct
import sys
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import MagicMock, patch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.audio_engine import (
    CloudAudioEngine,
    clean_text_for_speech,
    pcm16_rms,
    pcm16_to_wav_bytes,
    synthesize_tone_pcm,
)
from core.brain import JarvisBrain
from core.config import JarvisConfig, detect_provider_from_key
from core.memory import JarvisMemory
from tools import system_guard, windows_control
from tools.registry import OPENAI_TOOLS_SCHEMA


class TestFreeProviderDetection(unittest.TestCase):
    def test_key_prefix_routing(self) -> None:
        self.assertEqual(
            detect_provider_from_key("AIzaSyDummyFreeGeminiKey12345"),
            ("gemini", "GEMINI_API_KEY"),
        )
        self.assertEqual(
            detect_provider_from_key("gsk_DummyFreeGroqKey123456789"),
            ("groq", "GROQ_API_KEY"),
        )
        self.assertEqual(
            detect_provider_from_key("sk-or-v1-dummyopenrouterkey123"),
            ("openrouter", "OPENROUTER_API_KEY"),
        )

    def test_active_provider_failover_order(self) -> None:
        cfg = JarvisConfig(
            gemini_api_key="AIzaSyDummyFreeGeminiKey12345",
            groq_api_key="gsk_DummyFreeGroqKey123456789",
            provider="auto",
        )
        ordered = [p for p, _k in cfg.active_providers_ordered()]
        self.assertEqual(ordered, ["groq", "gemini"])


class TestFreeAudioRoundtrip(unittest.TestCase):
    def test_pcm16_rms_and_wav(self) -> None:
        self.assertEqual(pcm16_rms(b""), 0.0)
        tone = struct.pack("<h", 1200) * 400
        self.assertAlmostEqual(pcm16_rms(tone), 1200.0, places=2)

        pcm = synthesize_tone_pcm([(440.0, 0.08)], sample_rate=16000)
        wav_bytes = pcm16_to_wav_bytes(pcm, sample_rate=16000)
        with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
            self.assertEqual(wf.getframerate(), 16000)
            self.assertEqual(wf.readframes(wf.getnframes()), pcm)

    def test_live_free_edge_tts_and_zero_key_stt_roundtrip(self) -> None:
        """Synthesize British JARVIS voice for $0 via Edge-TTS and transcribe back for $0."""
        cfg = JarvisConfig(tts_voice="en-GB-RyanNeural", language="en")
        engine = CloudAudioEngine(cfg)

        pcm_24k = engine._synthesize_edge_tts_pcm("Open calculator please")
        self.assertGreater(len(pcm_24k), 10000)

        # Wrap 24kHz PCM as WAV and transcribe using Zero-Key Free SpeechRecognition
        wav_bytes = pcm16_to_wav_bytes(pcm_24k, sample_rate=24000)
        transcript = engine.transcribe_wav(wav_bytes)
        self.assertIn("calculator", transcript.lower())

    def test_clean_text_for_speech(self) -> None:
        cleaned = clean_text_for_speech("Check **bold** and `code` at https://example.com")
        self.assertNotIn("**", cleaned)
        self.assertNotIn("https://", cleaned)


class TestMemoryAndCrossProviderTools(unittest.TestCase):
    def test_tool_schemas_have_non_empty_properties_for_gemini_and_groq(self) -> None:
        for entry in OPENAI_TOOLS_SCHEMA:
            fn = entry["function"]
            props = fn["parameters"].get("properties", {})
            self.assertGreater(
                len(props),
                0,
                f"Tool {fn['name']} has empty properties dict (breaks strict Gemini validator)",
            )

    def test_memory_and_safety_blocks(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("core.memory.MEMORY_FILE", Path(tmpdir) / "mem.json"):
                mem = JarvisMemory()
                mem.remember_fact("Potato PC has 4GB RAM")
                self.assertIn("4GB RAM", mem.prompt_context_block())
        self.assertIn("Safety block", system_guard.close_application_processes("explorer.exe"))
        self.assertIn("No files or folders", windows_control.search_user_files("nonexistent_999_xyz"))


class TestMultiProviderBrainFailover(unittest.TestCase):
    def test_failover_from_first_provider_to_second_with_tool_call(self) -> None:
        cfg = JarvisConfig(
            groq_api_key="gsk_DummyFreeGroqKey123456789",
            gemini_api_key="AIzaSyDummyFreeGeminiKey12345",
            chat_model="gemini-2.5-flash",
        )
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("core.memory.MEMORY_FILE", Path(tmpdir) / "mem.json"):
                mem = JarvisMemory()
                brain = JarvisBrain(cfg, mem)

                # Simulate Groq rate-limiting (429), and Gemini succeeding cleanly with tool call -> answer
                failing_groq = MagicMock()
                failing_groq.chat.completions.create.side_effect = RuntimeError("429 rate limit")

                tc = MagicMock()
                tc.id = "call_free_1"
                tc.function.name = "get_pc_health_report"
                tc.function.arguments = json.dumps({"include_processes": True})

                msg1 = MagicMock(content="", tool_calls=[tc])
                msg2 = MagicMock(content="RAM usage is optimal, sir.", tool_calls=None)

                ok_gemini = MagicMock()
                ok_gemini.chat.completions.create.side_effect = [
                    MagicMock(choices=[MagicMock(message=msg1)]),
                    MagicMock(choices=[MagicMock(message=msg2)]),
                ]

                brain._clients[("groq", cfg.groq_api_key)] = failing_groq
                brain._clients[("gemini", cfg.gemini_api_key)] = ok_gemini

                reply = brain.ask("Check my RAM")
                self.assertEqual(reply, "RAM usage is optimal, sir.")


if __name__ == "__main__":
    unittest.main()
